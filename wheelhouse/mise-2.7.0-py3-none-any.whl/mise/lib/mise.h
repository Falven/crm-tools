// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#ifndef MISE_NATIVE_DLL_H
#define MISE_NATIVE_DLL_H

#define PathToLibrary "mise.dll"
#define PathToConfigurationFile "appsettings.json"

#define MISE_CONFIGURE_FUNCTION_NAME "MiseConfigure"
#define MISE_PREFETCH_FUNCTION_NAME "MisePrefetchOpenIdConfigurationAsync"

#define MISE_VALIDATE_FUNCTION_NAME "MiseValidate"
#define MISE_VALIDATE_ASYNC_FUNCTION_NAME "MiseValidateAsync"
#define MISE_VALIDATE_WITH_CONTEXT_ASYNC_FUNCTION_NAME "MiseValidateWithContextAsync"
#define MISE_VALIDATE_WITH_AZURE_AUTHORIZATION_MODULE_ASYNC_FUNCTION_NAME "MiseValidateWithAzureAuthorizationModuleAsync"

#define MISE_CALL_DOWNSTREAM_API_FUNCTION_NAME "MiseCallDownstreamApi"
#define MISE_CALL_DOWNSTREAM_UNAUTHENTICATED_API_FUNCTION_NAME "MiseCallDownstreamApiUnauthenticated"
#define MISE_CALL_DOWNSTREAM_API_ASYNC_FUNCTION_NAME "MiseCallDownstreamApiAsync"
#define MISE_CALL_DOWNSTREAM_UNAUTHENTICATED_API_ASYNC_FUNCTION_NAME "MiseCallDownstreamApiUnauthenticatedAsync"

#define MISE_GET_AUTHORIZATION_HEADER_FUNCTION_NAME "MiseGetAuthorizationHeader"
#define MISE_GET_AUTHORIZATION_HEADER_UNAUTHENTICATED_FUNCTION_NAME "MiseGetAuthorizationHeaderUnauthenticated"
#define MISE_GET_AUTHORIZATION_HEADER_ASYNC_FUNCTION_NAME "MiseGetAuthorizationHeaderAsync"
#define MISE_GET_AUTHORIZATION_HEADER_UNAUTHENTICATED_ASYNC_FUNCTION_NAME "MiseGetAuthorizationHeaderUnauthenticatedAsync"

#define MISE_ASSIGN_LOGMESSAGECALLBACK_FUNCTION_NAME "MiseAssignLogMessageCallback"
#define MISE_UNASSIGN_LOGMESSAGECALLBACK_FUNCTION_NAME "MiseUnassignLogMessageCallback"

#define MISE_ASSIGN_L2_CACHE_SET_DATA_CALLBACK "MiseAssignL2CacheSetDataCallback"
#define MISE_UNASSIGN_L2_CACHE_SET_DATA_CALLBACK "MiseUnassignL2CacheSetDataCallback"
#define MISE_ASSIGN_L2_CACHE_GET_DATA_CALLBACK "MiseAssignL2CacheGetDataCallback"
#define MISE_UNASSIGN_L2_CACHE_GET_DATA_CALLBACK "MiseUnassignL2CacheGetDataCallback"

#define MISE_ASSIGN_L2_CACHE_SET_DATA_ASYNC_CALLBACK "MiseAssignL2CacheSetDataAsyncCallback"
#define MISE_UNASSIGN_L2_CACHE_SET_DATA_ASYNC_CALLBACK "MiseUnassignL2CacheSetDataAsyncCallback"
#define MISE_ASSIGN_L2_CACHE_GET_DATA_ASYNC_CALLBACK "MiseAssignL2CacheGetDataAsyncCallback"
#define MISE_UNASSIGN_L2_CACHE_GET_DATA_ASYNC_CALLBACK "MiseUnassignL2CacheGetDataAsyncCallback"

#ifdef __cplusplus
#define MISE_EXTERN_C extern "C"
#else
#define MISE_EXTERN_C
#include <stdbool.h>  // This defines 'bool', 'true', and 'false' in C
#endif // __cplusplus

#ifdef _WIN32
#define MISE_WINDOWS
#else
#define MISE_LINUX
#endif // _WIN32

// Define some platform macros
#ifdef MISE_WINDOWS
#define MISE_API __declspec(dllimport)
#define MISE_CALLTYPE __stdcall
#else
#define MISE_API 
#define MISE_CALLTYPE
#endif // MISE_WINDOWS

// Python FFI can't read #defines. FFI BEGIN->END marks the FFI parse-able section.
// FFI BEGIN

/**
 * @brief Defines logging severity levels.
 *
 * Logging severity can be set through your config file's logging section.
 */
typedef enum
{
    MiseLogLevelTrace,       /* Logs that contain the most detailed messages.These messages may contain sensitive
                                    application data. These messages are disabled by default and should never be
                                    enabled in a production environment. */
    MiseLogLevelDebug,       /* Logs that are used for interactive investigation during development. These logs
                                    should primarily contain information useful for debugging and have no long-term value. */
    MiseLogLevelInformation, /* Logs that track the general flow of the application. These logs should have long-term value. */

    MiseLogLevelWarning,     /* Logs that highlight an abnormal or unexpected event in the application flow,
                                    but do not otherwise cause the application execution to stop. */

    MiseLogLevelError,       /* Logs that highlight when the current flow of execution is stopped due to a failure.
                                    These should indicate a failure in the current activity, not an application-wide failure. */

    MiseLogLevelCritical,    /* Logs that describe an unrecoverable application or system crash, or a catastrophic
                                    failure that requires immediate attention. */
    MiseLogLevelNone         /* Not used for writing log messages.Specifies that a logging category should not
                                    write any messages. */
} MiseLogLevel;

/**
 * @brief Specifies the code of an error.
 */
typedef enum
{
    MiseErrorNone = 0,                  /* No error. */
    MiseErrorOther = 1,                 /* The error does not belong to any of type defined in the enum. */
    MiseErrorTokenNotYetValid = 2,      /* Indicates that the token isn't valid yet. */
    MiseErrorTokenExpired = 3,          /* Indicates that the token has expired. */
    MiseErrorMissingExpirationTime = 4, /* Indicates that the token has missing expiration time. */
    MiseErrorNotBeforeAfterExpires = 5, /* Indicates that the token has not before time after expiration time. */
    MiseErrorInvalidAudience = 6,       /* Indicates that the audience does not match the expected value. */
    MiseErrorInvalidIssuer = 7,         /* Indicates that the issuer does not match the expected value. */
    MiseErrorInvalidSignature = 8,      /* Indicates that a verified signature does not match the token one. */
    MiseErrorInvalidTokenFormat = 9,    /* Indicates that token doesn't have expected format. */
    MiseErrorMissingSigningToken = 10,  /* Indicates that key which was used to sign the token is missing in metadata. */
} MiseErrorCode;

/**
 * @brief Context for message logging callback.
 *
 *  This structure will be filled out by MISE and passed to your assigned log callback function.
 */
MISE_EXTERN_C typedef struct _MiseLogMessageCallbackContext
{
    const char* message; /* The message to log. */
    MiseLogLevel level;  /* Severity of the log message. */
} MiseLogMessageCallbackContext;

/**
 * @brief Structure for an entry in error details.
 *
 * This structure contains information about single error which is present in error description.
 */
MISE_EXTERN_C typedef struct _MiseErrorEntry
{
    const char* errorType;    /* The error type string (e.g., IDX10500). */
    int errorCode;            /* The error code (MiseErrorCode enum). */
    const char* errorMessage; /* The error message if it differs from error description. */
} MiseErrorEntry;

/**
 * @brief Context for L2 cache get data callback.
 *
 *  This structure will be filled out by MISE and passed to your assigned callback function.
 */
MISE_EXTERN_C typedef struct _NativeL2CacheGetDataCallbackContext
{
    const char* key;   /* cache key to retrieve data for */
    int keySize;       /* Number of UTF-8 encoded bytes of key string. */
} NativeL2CacheGetDataCallbackContext;

/**
 * @brief Context for L2 cache set data callback.
 *
 *  This structure will be filled out by MISE and passed to your assigned callback function.
 */
MISE_EXTERN_C typedef struct _NativeL2CacheSetDataCallbackContext
{
    const char* key;    /* cache key to store data for */
    const char* data;   /* values to store */
    int keySize;  /* Number of UTF-8 encoded bytes of key string. */
    int dataSize; /* Number of UTF-8 encoded bytes of data string. */
    unsigned int absoluteExpirationRelativeToNowInSeconds; /* TTL for the data */
} NativeL2CacheSetDataCallbackContext;

/**
 * @brief Result structure for Mise control functions.
 *
 * This structure contains result values from MISE control functions.
 */
MISE_EXTERN_C typedef struct _MiseControlResult
{
    int errorCode;                /* Error code representing the outcome of a MISE control function. 0 when operation was successful. */
    const char* errorDescription; /* Description of the error, if any. */
} MiseControlResult;

/**
* @brief Structure for token claims.
*
* This structure describes a claim.
*/
MISE_EXTERN_C typedef struct _MiseClaim
{
    const char* name;
    const char* value;
} MiseClaim;

/**
 * @brief Defines Access Decisions.
 *
 * Access decisions returned by the Azure Authorization Module.
 */
typedef enum
{
    MiseAccessDecisionNotAllowed,
    MiseAccessDecisionAllowed,
    MiseAccessDecisionDenied,
} AccessDecision;

/**
* @brief Structure for Azure Authorization Module authorization response.
*
* This structure describes an authorization response.
*/
MISE_EXTERN_C typedef struct _MiseAuthorizationResponseResult
{
    AccessDecision AccessDecision;
    const char* ActionId;
    bool IsDataAction;
    const char* RoleAssignment;
    const char* DenyAssignment;
    int TimeToLiveInMs;
} MiseAuthorizationResponseResult;

/**
* @brief Structure for Azure Authorization Module authorization policy.
*
* This structure describes an authorization policy.
*/
MISE_EXTERN_C typedef struct _MiseAuthorizationPoliciesResult
{
    const char* RoleAssignments;
    const char* RoleDefinitions;
    const char* DenyAssignments;
    const char* PrincipalGroups;
    int TimeToLiveInMs;
} MiseAuthorizationPoliciesResult;

/**
 * @brief Structure for additional request headers.
 *
 * This structure describes a request header.
 */
MISE_EXTERN_C typedef struct _MiseRequestHeader
{
    const char* name; /* Name of the header. */
    const char* value; /* Value of the header. */
} MiseRequestHeader;

/**
 * @brief Result structure for retrieving OIDC metadata from a distributed cache.
 */
MISE_EXTERN_C typedef struct _MiseL2CacheGetDataCallbackResult
{
    const char* data;            /* OIDC data. */
    int dataSize;                /* Number of UTF-8 encoded bytes of data string. */
    int errorCode;               /* Error code representing the outcome of a retrieval. 0 when operation was successful. */
} MiseL2CacheGetDataCallbackResult;

/**
 * @brief Result structure for storing OIDC metadata to a distributed cache.
 */
MISE_EXTERN_C typedef struct _MiseL2CacheSetDataCallbackResult
{
    int errorCode;               /* Error code representing the outcome of a storing. 0 when operation was successful. */
} MiseL2CacheSetDataCallbackResult;

/**
 * @brief Input structure for Application Switches for the the MiseConfigure function.
 *
 * This structure is used to encapsulate input values passed to the MiseConfigure function.
 * Two supported switch options are MISE_SWITCH_REGISTER_CLAIMS_ONLY_AUTHZ and MISE_SWITCH_PARSE_SECURITY_CONTEXT.
 */
MISE_EXTERN_C typedef struct _MiseAppSwitchesInput
{
    const char** switches;
    unsigned int switchCount;
} MiseAppSwitchesInput;

/**
 * @brief Input structure for the MiseValidate function.
 *
 * This structure is used to encapsulate input values passed to a MISE data function.
 */
MISE_EXTERN_C typedef struct _MiseValidationInput
{
    const char* authorizationHeader;                    /* Value for the Authorization header received by the web API that uses MISE native. */
    const char* xForwardedForHeader;                    /* Value for the X-Forwarded-For header. */
    const char* originalUriHeader;                      /* Original URI header value. This is the URL on which the web API using MISE native was called. */
    const char* originalMethodHeader;                   /* Original HTTP method header value (CONNECT, DELETE, GET, HEAD, PATCH, POST, PUT, TRACE). This is used in protocols like PoP. */
    const char* miseCorrelationId;                      /* Correlation ID used to trace requests; if you want to see it in the logs. */
    const MiseRequestHeader* additionalHeaderValues;    /* Array of additional header values. To skip AzureAuthorizationModule for this input, add header of Name = AzureAuthorizationSkipAttribute.AzureAuthorizationSkipHeader and Value = "skip". */
    unsigned int additionalHeaderValuesCount;           /* Count of additional headers in the additionalHeaderValues array. */
} MiseValidationInput;

/*
 * @brief Optional flat snapshot of the inbound identity context needed for outbound token acquisition
 * (notably MSAuth 1.0 AT_POP / MTLS_POP+CDT envelope construction).
 *
 * Pointed to by `MiseValidationResult::claimsIdentityContext` when applicable. A NULL pointer in the
 * outer struct means "no AT_POP context for this request" — the inbound flow had nothing the
 * outbound strategy would walk the identity for (e.g. a plain bearer flow or MSI). When non-NULL,
 * memory for the struct and its strings is co-allocated inside the same block that backs the
 * owning `MiseValidationResult`, so it is freed together with that struct.
 */
MISE_EXTERN_C typedef struct _MiseClaimsIdentityContext
{
    const char* pft;                       /* Raw PFT string used by MSAuth 1.0 AT_POP / MTLS_POP+CDT envelope construction. May be null. */
    const char* cdt;                       /* Raw CDT string. Mutually exclusive with `pft` on the envelope side (AT_POP emits CDT when present). May be null. */
    const char* tid;                       /* Pre-resolved tenant id (CDT.tid -> Actor.tid -> Subject.tid cascade). Used as the outbound `AcquireTokenOptions.Tenant`. May be null. */
} MiseClaimsIdentityContext;

/*
 * @brief Result structure for MiseValidate function.
 *
 * This structure contains the result of the MiseValidate function.
 */
MISE_EXTERN_C typedef struct _MiseValidationResult
{
    unsigned int httpResponseStatusCode;   /* The http status code: 401 if the request to your web API was computed as un-authenticated, 403, if it was unauthorized.
                                                200 if the authentication request is valid. In the case of a 401 or 403, the WWWAuthenticate string may contain
                                                information for your client application. You should return it as the WWWAuthenticate header for your HTTP response if present. */
    const char* correlationId;             /* Correlation ID. */
    const char* errorDescription;          /* The ErrorDescription will contain additional information if there was an error. To debug errors you can also enable the logs. */
    const char* wwwAuthenticate;           /* WWW-Authenticate header value, if any, when HttpResponseStatusCode is 401 or 403. */
    const char* subjectToken;              /* Subject token, if any. */
    const char* subjectTokenType;          /* Subject token type, if subject token is set. */
    const char* actorToken;                /* Actor token, if any. */
    const char* popServerNonce;            /* PopServerNonce, corresponds to PopServerNonce field from the RFC and may contain pop server nonce, if set. */
    const char* authenticationScheme;      /* Authentication scheme, if any. */
    const MiseClaim* subjectClaims;        /* Subject claims, if any. */
    unsigned int subjectClaimsCount;       /* Subject claims count. */
    const MiseClaim* actorClaims;          /* Actor claims, if any. */
    unsigned int actorClaimsCount;         /* Actor claims count. */
    const char* authZDetailsBlob;          /* Payload of the AuthZ token. */
    const MiseAuthorizationPoliciesResult* authorizationPolicies; /* Authorization policies, if any and requested. */
    const MiseAuthorizationResponseResult* authorizationResponse; /* Authorization response, if successful and requested. */
    unsigned int authorizationResponseCount; /* Number of authorization responses. */
    const MiseClaimsIdentityContext* claimsIdentityContext; /* Optional flat outbound identity context (PFT/CDT/tid). NULL when not applicable; otherwise lives in the same allocation block as this struct. */
    const MiseErrorEntry* errors;          /* Error details parsed from error description, if any. */
    unsigned int errorCount;               /* Error details count (same as errorDetails->errorCount for convenience). */
} MiseValidationResult;

/**
 * @brief Override structure for the MiseDownstreamApiInput and MiseDownstreamAuthorizationHeaderInput input structs.
 *
 * This structure can optionally be used to override config options.
 */
MISE_EXTERN_C typedef struct _MiseDownstreamApiOptionsOverrides
{
    const char** scopes;                                 /* List of scopes as null terminated strings. */
    unsigned int scopesCount;                            /* Count of scopes being passed in the scopes field. */
    const char* tenant;                                  /* (Entra ID specific) Enables to override the tenant / account for which to get a token. */
    const char* claimsJson;                              /* A string with one or multiple claims to request. Must be a json blob (encoded or not).
                                                             e.g., {"access_token":{"xms_cc":{"values":["cp1"]}}} */
    const char* managedIdentityClientId;                 /* Client ID to be used with managed identity. */
    const char* managedIdentityBase64encodedCertificate; /* Base64 encoded cert to be used with managed identity. */
    const char* azureRegion;                             /* Instructs MISE to use Entra ID regional STS (ESTS-Regional). This feature is currently available to first-party applications only. Both managedIdentityClientId and managedIdentityBase64encodedCertificate must also be passed when using this parameter. */
    const char* signedClientAssertion;                   /* Signed client assertion to be used for OBO flow in SQL MI. Use either signedClientAssertion or managedIdentityBase64encodedCertificate. Not both. */
    const char* fmiPath;                                 /* Fmi Path*/
    int forceRefresh;                                    /* Skip cached token and get it from the STS. */
    const char* authorizationDetails;                    /* Authorization details to be used with the authorization token provider.*/
    const char* pdpConfigurationSection;                 /* Configuration Name for the section of PDP to get AuthZ Token */
    const char* relativePath;                            /* URL path to be appended for the downstream API call. This is used appended to the URL path defined in the configuration file. */
    const char** constraints;                            /* Constraints as JSON object*/
    unsigned int constraintsCount;                       /* Count of constraints passed*/
    const char** attributeTokens;                        /* Attribute tokens to be used when acquiring AuthN tokens.*/
    unsigned int attributeTokensCount;                   /* Count of Attribute tokens being passed in the AttributeTokens field. */
    const char* constraintTenant;                        /* (Entra ID specific) Enables to override the constraint tenant (c.tid) in CDT tokens. If not set, uses 'tenant' value provided in current struct. */
    const char* longRunningWebApiSessionKey;             /* Key for long-running web API session. */
    const char* clientAssertionClaims;                   /* Optional client claims to add to the client assertion when using managedIdentityBase64encodedCertificate. Claim names need to be unique otherwise they will be silently overwritten. Claims should be in the form of a JSON dictionary serialized as a string*/
} MiseDownstreamApiOptionsOverrides, MiseAuthorizationHeaderOptionsOverrides;

/**
 * @brief Input structure for the MiseGetAuthorizationHeader and MiseGetAuthorizationHeaderUnauthenticated functions.
 *
 * This structure is used to encapsulate input values passed to a MISE data function.
 */
MISE_EXTERN_C typedef struct _MiseDownstreamAuthorizationHeaderInput
{
    const char* correlationId;                          /* Correlation ID. */
    MiseAuthorizationHeaderOptionsOverrides overrides;  /* (Optional) Override config file settings for this particular call. */

} MiseDownstreamAuthorizationHeaderInput;

/**
 * @brief Result structure for the MiseGetAuthorizationHeader function.
 *
 * This structure contains the result of the MISE GetAuthorizationHeader header function.
 * If MISE native successfully acquired an authorization header, the AuthorizationHeader field will be set, and
 * the ErrorDescription field and WWWAuthenticate will be NULL.
 * If MISE native fails to acquire an authorization header, the AuthorizationHeader field will be NULL, the ErrorDescription
 * will explain the error, and, if the web API calling MISE needs to request more claims from its client application the WWWAuthenticate
   field will contain the WWW-Authenticate header value that the web API needs to return to its client. This would, for example be:
   the case for a claims challenge for CAE.
 */
MISE_EXTERN_C typedef struct _MiseDownstreamAuthorizationHeaderResult
{
    unsigned int httpResponseStatusCode;     /* HTTP response status code. 200 means success, 401 unauthorized (bad token or bad protocol), 404 not found. */
    const char* correlationId;               /* Correlation ID. */
    const char* errorDescription;            /* Description of the error, if any. */
    const char* wwwAuthenticate;             /* WWW-Authenticate header value, if any, when the web API using MISE needs to request
                                                more claims from its client (claims challenge for CAE, for instance). */
    const char* authorizationHeader;         /* Result Authorization header that the web API that uses MISE native can use to call the downstream API. */
    void* bindingCertificate;                /* Platform-specific certificate data (PCCERT_CONTEXT on Windows and nullptr on other platforms). */
    const char* longRunningWebApiSessionKey; /* Optional long running web API session key, auto-generated when corresponding input overrides has "AllocateForMe" specified. */
    const char* metadata;                    /* Optional token-acquisition metadata as a JSON string (token source, cache level/refresh reason, region, durations, expiry/refresh times), or NULL when unavailable.
                                                For diagnostics/telemetry only: the content and format are not contractual and may change - do not parse or take a dependency on it. */
    const char* failureDetails;              /* Optional token-acquisition failure diagnostics as a JSON string (error code, sub-error, HTTP status, claims challenge, correlation id), or NULL on success / when unavailable.
                                                For diagnostics/telemetry only: the content and format are not contractual and may change - do not parse or take a dependency on it. */
} MiseDownstreamAuthorizationHeaderResult;

/**
 * @brief Input structure for the MISECallDownstreamApi and MiseCallDowstreamApiUnauthenticated functions.
 *
 * This structure is used to encapsulate input values passed to a MISE data function.
 */
MISE_EXTERN_C typedef struct _MiseDownstreamApiInput
{
    const char* correlationId;                    /* Correlation ID. */
    const char* contentType;                      /* (Optional) Content type for body. By default text-json. */
    const char* inputBody;                        /* Request body. */
    const char* acceptHeader;                     /* (Optional) Accept header. By default text-json. */
    MiseDownstreamApiOptionsOverrides overrides;  /* (Optional) Override config file settings for this particular call. */
} MiseDownstreamApiInput;

/**
 * @brief Result structure for the MiseCallDownstreamApi function.
 *
 * This structure contains the result obtained from a MISE native when calling a downstream API. If MISE native successfully
 * called the downstream API, the DownstreamApiResult field will be set with the body of the response from the downstream Api,
   and the ErrorDescription field and WWWAuthenticate will be NULL.
   If MISE native fails to call the downstream API, the DownstreamApiResult field will be NULL, the ErrorDescription will explain
   the error, and, if the web API calling MISE needs to request more claims from its client application the WWWAuthenticate field
   will contain the WWW-Authenticate header value that the web API needs to return to its client. This would, for exemple be the
   case for a claims challenge for CAE.
 */
MISE_EXTERN_C typedef struct _MiseDownstreamApiResult
{
    unsigned int httpResponseStatusCode;   /* HTTP response status code. 200 means success, 401 unauthorized (bad token or bad protocol), 404 not found. */
    const char* correlationId;             /* Correlation ID. */
    const char* errorDescription;          /* Description of the error, if any. */
    const char* wwwAuthenticate;           /* WWW-Authenticate header value, if any, when the web API using MISE needs to request
                                              more claims from its client (claims challenge for CAE, for instance). */
    const char* downstreamApiResult;       /* Content of the body of the downstream API response. */
} MiseDownstreamApiResult;

/**
 * @brief Type definition for the MiseConfigure function.
 *
 * Initializes the MISE Native library, making it ready to call flow functions.
 *
 * @param configurationJson - The MISE Native JSON configuration. See https://aka.ms/mise/container/config
 * @param configurationSection - Optional: section name in the configuration JSON, 'AzureAd' if NULL.
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseConfigure(const char* configurationJson, const char* configurationSection);


/**
 * @brief Type definition for the MiseConfigure function.
 *
 * Initializes the MISE Native library, making it ready to call flow functions.
 *
 * @param configurationJson - The MISE Native JSON configuration. See https://aka.ms/mise/container/config
 * @param configurationSection - Optional: section name in the configuration JSON, 'AzureAd' if NULL.
 * @param appSwitches - Application options. Two supported switch options are MISE_SWITCH_REGISTER_CLAIMS_ONLY_AUTHZ and MISE_SWITCH_PARSE_SECURITY_CONTEXT.
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseConfigureWithAppSwitches(const char* configurationJson, const char* configurationSection, MiseAppSwitchesInput* appSwitches);


/**
* @brief Type definition for the request MiseCompletionCallback function.
*
* This function type is intended to be implemented by consumers of the API to handle results of pre-fetch requests.
*
* @param miseControlResult - Pointer representing the pre-fetch operation result.
* @param callerContext - Optional: A user-defined pointer representing state that might be needed within the callback.
*/
typedef void(*MiseCompletionCallbackFunc)(MiseControlResult* miseControlResult, void* callerContext);

/**
 * @brief Type definition for the MisePrefetchOpenIdConfigurationAsync function.
 *
 * This function warms up OIDC metadata caches (local and L2 cache if set).
 * MiseCompletionCallbackFunc will be called when the operation is completed.
 * Observe ErrorCode in the result structure to determine the outcome:
 * 0 - success
 * 1 - environment issue (non retriable)
 * 2 - authenticationManager is null (non retriable)
 * 3 - no inbound policies (non retriable)
 * 4 - timeout (retriable)
 * 5 - other exception (retriable); see details
 * 6 - unexpected (retriable)
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MisePrefetchOpenIdConfigurationAsync(unsigned int timeoutInSeconds, MiseCompletionCallbackFunc completionCallback, void* nativeContext);


/**
 * @brief Type definition for the validation function.
 *
 * Validates authentication using a provided input structure.
 * This function offers a validation functionality with extracted commonly used fields.
 *
 * @param input - The input headers structured as `MiseValidationInput`.
 * @return MiseValidationResult: Pointer to result structure with the outcome of the validation. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseValidationResult* MISE_CALLTYPE MiseValidate(const MiseValidationInput* input);


/**
* @brief Type definition for the request contextcallback function.
*
* This function type is intended to be implemented by consumers of the API to handle customising validate requests.
* An opaque pointer representing the current request will be passed from MISE to this function.
*
* @param requestObject - An opaque pointer representing the current request
* @param callerContext - Optional: A user-defined pointer representing state that might be needed within the callback.
* MiseLogMessageCallbackFunc
*/
typedef void(*MiseValidateRequestContextCallbackFunc)(void* requestObject, void* callerContext);

/**
 * @brief Type definition for the validation function that requires context callback.
 *
 * Validates authentication using a provided input structure.
 * This function offers a validation functionality with extracted commonly used fields.
 *
 * @param input - The input headers structured as `MiseValidationInput`.
 * @param callback - The callback function that will receive request context.
 * @param callerContext - Optional: An opaque object that will be returned as the second parameter in the callback
 * @return MiseValidationResult: Pointer to result structure with the outcome of the validation. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseValidationResult* MISE_CALLTYPE MiseValidateWithContext(const MiseValidationInput* input,
    MiseValidateRequestContextCallbackFunc callback, void* callerContext);

/**
 * @brief Type definition for the function that sets request claims
 *
 * Sets the claims based auth for the current request
 *
 * @param requestObject - Opaque pointer representing the current request object. This is the requestObject received in the callback MiseValidateRequestContextCallbackFunc
 * @param policies - An array representing policies
 * @param policyCount - Count of policies
 * @return MiseValidationResult: Pointer to result structure with the outcome. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseSetClaimsPolicies(void* requestObject, char** policies, unsigned int policyCount);

/**
 * @brief Type definition for the function that sets data fetch request payload on the mise context
 *
 * Sets the authorization request payload on the mise context
 *
 * @param requestObject - Opaque pointer representing the current request object. This is the requestObject received in the callback MiseValidateRequestContextCallbackFunc
 * @param authorizationRequest - The authorization request payload as a string
 * @return MiseValidationResult: Pointer to result structure with the outcome. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseSetAzureAuthorizationRequestPayload(void* requestObject, const char* authorizationRequest);

/**
 * @brief Type definition for the function that sets data fetch request payload on the mise context
 *
 * Sets the data fetch request payload on the mise context
 *
 * @param requestObject - Opaque pointer representing the current request object. This is the requestObject received in the callback MiseValidateRequestContextCallbackFunc
 * @param dataFetchRequest - The data fetch request payload as a string
 * @return MiseValidationResult: Pointer to result structure with the outcome. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseSetAzureAuthorizationDataFetchPayload(void* requestObject, const char* dataFetchRequest);

/**
 * @brief Type definition for the validation function that requires context callback for Azure Authorization module.
 *
 * Validates authentication using a provided input structure and Azure Authorization module
 * This function offers a validation functionality with extracted commonly used fields.
 *
 * @param input - The input headers structured as `MiseValidationInput`.
 * @param callback - The callback function that will receive request context.
 * @param callerContext - Optional: An opaque object that will be returned as the second parameter in the callback
 * @return MiseValidationResult: Pointer to result structure with the outcome of the validation. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseValidationResult* MISE_CALLTYPE MiseValidateWithAzureAuthorizationModule(
    const MiseValidationInput* input,
    MiseValidateRequestContextCallbackFunc callback,
    void* callerContext);

/**
* @brief Type definition for a log message callback function.
*
* This function type is intended to be implemented by consumers of the API to handle logging.
* Log messages will be passed from MISE to this function.
*
* @param managedContext - pointer to a structure that contains the contextual information for the log message passed from MISE. Must be freed by caller.
* @param nativeContext - Optional: A user-defined pointer to additional native context or state that might be needed within the callback.
*/
typedef void(*MiseLogMessageCallbackFunc)(MiseLogMessageCallbackContext* managedContext, void* nativeContext);

/**
 * @brief Assigns a user logging callback function to MISE.
 *
 * Because the callback needs to be assigned before MISE is initialized, this function needs to be called before 'Configure'.
.* This function is expected to be called only once.
 *
 * @param callback - The user-defined callback function as described by the function type definition.
 * @param nativeContext - Optional: A user-defined pointer to additional native context or state that might be needed within the callback.
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
*/
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseAssignLogMessageCallback(MiseLogMessageCallbackFunc callback, void* nativeContext);

/**
 * @brief Unassigns the logging message callback function.
 *
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseUnassignLogMessageCallback();

/**
* @brief Type definition for a L2 cache get data callback function.
*
* This function type is intended to be implemented by consumers of the API to get OIDC metadata from an L2 cache.
*
* @param managedContext - pointer to a structure that contains the cache key and its size, passed from MISE.
* @param nativeContext - Optional: A user-defined pointer to additional native context or state that might be needed within the callback.
*/
typedef const MiseL2CacheGetDataCallbackResult*(*MiseL2CacheGetDataCallbackFunc)(NativeL2CacheGetDataCallbackContext* managedContext, void* nativeContext);


/**
* @brief Type definition for a function that frees MiseL2CacheGetDataCallbackResult memory.
*
* This function type is intended to be implemented by consumers of the API who are instantiating MiseL2CacheGetDataCallbackResult.
*
* @param result - result object to be freed.
*/
typedef const void (*MiseFreeL2CacheGetDataResultCallbackFunc)(MiseL2CacheGetDataCallbackResult* result);

/**
* @brief Type definition for a L2 cache set data callback function.
*
* This function type is intended to be implemented by consumers of the API to set OIDC metadata to an L2 cache.
*
* @param managedContext - pointer to a structure that contains information about data to be stored in L2 cache, passed from MISE.
* @param nativeContext - Optional: A user-defined pointer to additional native context or state that might be needed within the callback.
*/
typedef const MiseL2CacheSetDataCallbackResult* (*MiseL2CacheSetDataCallbackFunc)(NativeL2CacheSetDataCallbackContext* managedContext, void* nativeContext);

/**
* @brief Type definition for a function that frees MiseL2CacheSetDataCallbackResult memory.
*
* This function type is intended to be implemented by consumers of the API who are instantiating MiseL2CacheSetDataCallbackResult.
*
* @param result - result object to be freed.
*/
typedef const void (*MiseFreeL2CacheSetDataResultCallbackFunc)(MiseL2CacheSetDataCallbackResult* result);

/**
 * @brief Assigns a user callback for the L2 cache get data function to MISE.
 *
 * Because the callback needs to be assigned before MISE is initialized, this function needs to be called before 'Configure'.
.* This function is expected to be called only once.
 *
 * @param callback - The user-defined callback function as described by the function type definition.
 * @param freeResultCallback - The user-defined callback function as described by the function type definition.
 * @param nativeContext - Optional: A user-defined pointer to additional native context or state that might be needed within the callback.
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
*/
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseAssignL2CacheGetDataCallback(MiseL2CacheGetDataCallbackFunc callback, MiseFreeL2CacheGetDataResultCallbackFunc freeResultCallback, void* nativeContext);

/**
 * @brief Unassigns the L2 cache get data callback function.
 *
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseUnassignL2CacheGetDataCallback();

/**
 * @brief Assigns a user callback for the L2 cache set data function to MISE.
 *
 * Because the callback needs to be assigned before MISE is initialized, this function needs to be called before 'Configure'.
.* This function is expected to be called only once.
 *
 * @param callback - The user-defined callback function as described by the function type definition.
 * @param freeResultCallback - The user-defined callback function as described by the function type definition.
 * @param nativeContext - Optional: A user-defined pointer to additional native context or state that might be needed within the callback.
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
*/
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseAssignL2CacheSetDataCallback(MiseL2CacheSetDataCallbackFunc callback, MiseFreeL2CacheSetDataResultCallbackFunc freeResultCallback, void* nativeContext);

/**
 * @brief Unassigns the L2 cache set data callback function.
 *
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseUnassignL2CacheSetDataCallback();

/**
* @brief Type definition for the completion callback invoked by an async L2 cache get data callback.
*
* MISE passes this function pointer (together with a completionContext) to your async get-data callback.
* Invoke it exactly once, when the asynchronous read has completed, to hand the result back to MISE.
* MISE takes ownership of the result and will free it using the registered MiseFreeL2CacheGetDataResultCallbackFunc.
* Passing NULL as the result is treated as a cache miss.
*
* @param result - the result of the get operation, or NULL for a cache miss.
* @param completionContext - the MISE-provided completion context to pass back unchanged.
*/
typedef void (*MiseL2CacheGetDataCompletionCallbackFunc)(const MiseL2CacheGetDataCallbackResult* result, void* completionContext);

/**
* @brief Type definition for a non-blocking (async) L2 cache get data callback function.
*
* This function type is intended to be implemented by consumers who want to read OIDC metadata from an L2 cache
* without blocking the calling thread. The callback should start the asynchronous read and return immediately;
* when the read completes it must invoke completionCallback(result, completionContext) exactly once.
*
* The callback must invoke completionCallback exactly once - either before returning or later, on any thread -
* including on failure (pass a result with a non-zero ErrorCode, or NULL for a cache miss). It must never invoke
* completionCallback more than once, and must never complete the operation without invoking it: failing to invoke
* completionCallback leaks the per-call state and leaves the originating request pending indefinitely.
*
* @param managedContext - pointer to a structure that contains the cache key and its size, passed from MISE.
* @param nativeContext - Optional: A user-defined pointer to additional native context or state.
* @param completionCallback - the MISE-provided completion callback to invoke when the read completes.
* @param completionContext - the MISE-provided completion context to pass back to completionCallback unchanged.
*/
typedef void (*MiseL2CacheGetDataCallbackAsyncFunc)(NativeL2CacheGetDataCallbackContext* managedContext, void* nativeContext, MiseL2CacheGetDataCompletionCallbackFunc completionCallback, void* completionContext);

/**
* @brief Type definition for the completion callback invoked by an async L2 cache set data callback.
*
* MISE passes this function pointer (together with a completionContext) to your async set-data callback.
* Invoke it exactly once, when the asynchronous write has completed, to hand the result back to MISE.
* MISE takes ownership of the result and will free it using the registered MiseFreeL2CacheSetDataResultCallbackFunc.
* Passing NULL as the result is treated as a successful no-op.
*
* @param result - the result of the set operation, or NULL for a successful no-op.
* @param completionContext - the MISE-provided completion context to pass back unchanged.
*/
typedef void (*MiseL2CacheSetDataCompletionCallbackFunc)(const MiseL2CacheSetDataCallbackResult* result, void* completionContext);

/**
* @brief Type definition for a non-blocking (async) L2 cache set data callback function.
*
* This function type is intended to be implemented by consumers who want to write OIDC metadata to an L2 cache
* without blocking the calling thread. The callback should start the asynchronous write and return immediately;
* when the write completes it must invoke completionCallback(result, completionContext) exactly once.
*
* The callback must invoke completionCallback exactly once - either before returning or later, on any thread -
* including on failure (pass a result with a non-zero ErrorCode, or NULL for a successful no-op). It must never
* invoke completionCallback more than once, and must never complete the operation without invoking it: failing to
* invoke completionCallback leaks the per-call state and leaves the originating request pending indefinitely.
*
* @param managedContext - pointer to a structure that contains the data to store, passed from MISE.
* @param nativeContext - Optional: A user-defined pointer to additional native context or state.
* @param completionCallback - the MISE-provided completion callback to invoke when the write completes.
* @param completionContext - the MISE-provided completion context to pass back to completionCallback unchanged.
*/
typedef void (*MiseL2CacheSetDataCallbackAsyncFunc)(NativeL2CacheSetDataCallbackContext* managedContext, void* nativeContext, MiseL2CacheSetDataCompletionCallbackFunc completionCallback, void* completionContext);

/**
 * @brief Assigns a non-blocking (async) user callback for the L2 cache get data function to MISE.
 *
 * When assigned, MISE awaits this callback instead of blocking a thread-pool thread on a cache miss, making the
 * cold-cache validation path fully non-blocking. The async callback takes precedence over a synchronous get callback
 * if both are assigned. Because the callback needs to be assigned before MISE is initialized, this function needs to
 * be called before 'Configure'. This function is expected to be called only once.
 *
 * @param callback - The user-defined async callback function as described by the function type definition.
 * @param freeResultCallback - The user-defined callback used to free the result handed to the completion callback.
 * @param nativeContext - Optional: A user-defined pointer to additional native context or state.
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
*/
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseAssignL2CacheGetDataAsyncCallback(MiseL2CacheGetDataCallbackAsyncFunc callback, MiseFreeL2CacheGetDataResultCallbackFunc freeResultCallback, void* nativeContext);

/**
 * @brief Unassigns the non-blocking (async) L2 cache get data callback function.
 *
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseUnassignL2CacheGetDataAsyncCallback();

/**
 * @brief Assigns a non-blocking (async) user callback for the L2 cache set data function to MISE.
 *
 * When assigned, MISE awaits this callback instead of blocking a thread-pool thread, making the cold-cache validation
 * path fully non-blocking. The async callback takes precedence over a synchronous set callback if both are assigned.
 * Because the callback needs to be assigned before MISE is initialized, this function needs to be called before
 * 'Configure'. This function is expected to be called only once.
 *
 * @param callback - The user-defined async callback function as described by the function type definition.
 * @param freeResultCallback - The user-defined callback used to free the result handed to the completion callback.
 * @param nativeContext - Optional: A user-defined pointer to additional native context or state.
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
*/
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseAssignL2CacheSetDataAsyncCallback(MiseL2CacheSetDataCallbackAsyncFunc callback, MiseFreeL2CacheSetDataResultCallbackFunc freeResultCallback, void* nativeContext);

/**
 * @brief Unassigns the non-blocking (async) L2 cache set data callback function.
 *
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseUnassignL2CacheSetDataAsyncCallback();

/**
* @brief Type definition for an RBAC change event notification filter callback function.
*
* This function type is intended to be implemented by consumers of the API to decide
* whether a given RBAC change event notification should be processed.
*
* @param tenantId - The tenant ID associated with the notification.
* @param resourceIds - An array of resource IDs (scopes) from the notification.
* @param resourceIdsCount - The number of elements in the resourceIds array.
* @param nativeContext - Optional: A user-defined pointer to additional native context or state that might be needed within the callback.
* @return bool: True if the notification should be processed, false otherwise.
*/
typedef bool(*MiseRbacChangeEventNotificationFilterCallbackFunc)(const char* tenantId, const char** resourceIds, unsigned int resourceIdsCount, void* nativeContext);

/**
 * @brief Assigns a user callback for filtering RBAC change event notifications.
 *
 * Because the callback needs to be assigned before MISE is initialized, this function needs to be called before 'MiseConfigure'.
 * This function is expected to be called only once.
 *
 * @param callback - The user-defined callback function for filtering.
 * @param nativeContext - Optional: A user-defined pointer to additional native context or state that might be needed within the callback.
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
*/
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseAssignRbacChangeEventNotificationFilterCallback(MiseRbacChangeEventNotificationFilterCallbackFunc callback, void* nativeContext);

/**
 * @brief Unassigns the RBAC change event notification filter callback function.
 *
 * @return MiseControlResult: Result structure with ErrorCode set to 0 on success. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseControlResult* MISE_CALLTYPE MiseUnassignRbacChangeEventNotificationFilterCallback();

/**
 * @brief Invokes a downstream API.
 *
 * that require authentication as provided in the input.
 *
 * @param validationResult - Pointer to result structure from Validate.
 * @param input - Provides the necessary data for performing the downstream api request.
 * @param downstreamApiName - The name or identifier of the downstream API being called as defined in the 'DownstreamApi' configuration section.
 * @return MiseDownstreamApiResult: Pointer to result structure encapsulating the outcome and potential errors from the API call. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseDownstreamApiResult* MISE_CALLTYPE MiseCallDownstreamApi(const MiseValidationResult* validationResult, const MiseDownstreamApiInput* input, const char* downstreamApiName);

/**
 * @brief Invokes a downstream API.
 *
 * The call is intended for endpoints that do not require authentication.
 *
 * @param input - Provides the necessary data for authenticating the request.
 * @param downstreamApiName - The name or identifier of the downstream API being called as defined in the 'DownstreamApi' configuration section.
 * @return MiseDataResult: Pointer to result structure encapsulating the outcome and potential errors from the API call. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseDownstreamApiResult* MISE_CALLTYPE MiseCallDownstreamApiUnauthenticated(const MiseDownstreamApiInput* input, const char* downstreamApiName);

/**
 * @brief Acquires an authentication token required to call a downstream API.
 *
 * This function is intended for consumers of the API to facilitate token acquisition for calling a downstream API.
 *
 * @param validationResult - Pointer to result structure from Validate.
 * @param downstreamApiName - The name or identifier of the downstream API being called as defined in the 'DownstreamApi' configuration section.
 * @return MiseDownstreamAuthorizationHeaderResult: Pointer to result structure containing the Authorization header or error information. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseDownstreamAuthorizationHeaderResult* MISE_CALLTYPE MiseGetAuthorizationHeader(const MiseValidationResult* validationResult, const MiseDownstreamAuthorizationHeaderInput* input, const char* downstreamApiName);

/**
 * @brief Acquires an authentication token required to call a downstream API.
 *
 * This function is intended for consumers of the API to facilitate token acquisition for calling a downstream API.
 * The call is intended for endpoints that do not require authentication.
 *
 * @param downstreamApiName - The name or identifier of the downstream API being called as defined in the 'DownstreamApi' configuration section.
 * @return MiseDownstreamAuthorizationHeaderResult: Pointer to result structure containing the Authorization header or error information. Must be freed by caller.
 */
MISE_EXTERN_C MISE_API const MiseDownstreamAuthorizationHeaderResult* MISE_CALLTYPE MiseGetAuthorizationHeaderUnauthenticated(const MiseDownstreamAuthorizationHeaderInput* input, const char* downstreamApiName);

// ==========================================
// Async APIs
// ==========================================

/**
 * @brief Type definition for the validation completion callback function.
 *
 * This function type is intended to be implemented by consumers of the API to handle results of async validation requests.
 * The callback is invoked exactly once, either with a successful result or with an error result.
 *
 * @param miseValidationResult - Pointer representing the validation operation result. Must be freed by caller via MiseFreeValidationResult.
 * @param callerContext - Optional: A user-defined pointer representing state that might be needed within the callback.
 */
typedef void(*MiseValidationCompletionCallbackFunc)(MiseValidationResult* miseValidationResult, void* callerContext);

/**
 * @brief Type definition for the downstream API completion callback function.
 *
 * This function type is intended to be implemented by consumers of the API to handle results of async downstream API requests.
 * The callback is invoked exactly once, either with a successful result or with an error result.
 *
 * @param miseDownstreamApiResult - Pointer representing the downstream API operation result. Must be freed by caller via MiseFreeDownstreamApiResult.
 * @param callerContext - Optional: A user-defined pointer representing state that might be needed within the callback.
 */
typedef void(*MiseDownstreamApiCompletionCallbackFunc)(MiseDownstreamApiResult* miseDownstreamApiResult, void* callerContext);

/**
 * @brief Type definition for the get authorization header completion callback function.
 *
 * This function type is intended to be implemented by consumers of the API to handle results of async authorization header requests.
 * The callback is invoked exactly once, either with a successful result or with an error result.
 *
 * @param miseDownstreamAuthorizationHeaderResult - Pointer representing the authorization header operation result. Must be freed by caller via MiseFreeDownstreamAuthorizationHeaderResult.
 * @param callerContext - Optional: A user-defined pointer representing state that might be needed within the callback.
 */
typedef void(*MiseGetAuthorizationHeaderCompletionCallbackFunc)(MiseDownstreamAuthorizationHeaderResult* miseDownstreamAuthorizationHeaderResult, void* callerContext);

/**
 * @brief Asynchronously validates authentication using a provided input structure.
 *
 * The completionCallback is invoked exactly once on a threadpool thread when validation completes (success or failure).
 * The caller must free the result via MiseFreeValidationResult.
 *
 * @param input - The input headers structured as `MiseValidationInput`.
 * @param completionCallback - The callback function invoked with the validation result upon completion.
 * @param nativeContext - Optional: A user-defined pointer to additional native context or state that will be passed to the callback.
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseValidateAsync(const MiseValidationInput* input, MiseValidationCompletionCallbackFunc completionCallback, void* nativeContext);

/**
 * @brief Asynchronously validates authentication using a provided input structure with a request context callback.
 *
 * The requestContextCallback is invoked synchronously before async validation begins, allowing the caller to modify the request context.
 * The completionCallback is invoked exactly once on a threadpool thread when validation completes (success or failure).
 * The caller must free the result via MiseFreeValidationResult.
 *
 * @param input - The input headers structured as `MiseValidationInput`.
 * @param requestContextCallback - The callback function that will receive request context (invoked synchronously).
 * @param callerContext - Optional: An opaque object that will be returned as the second parameter in the requestContextCallback.
 * @param completionCallback - The callback function invoked with the validation result upon completion.
 * @param completionNativeContext - Optional: A user-defined pointer to additional native context or state that will be passed to the completionCallback.
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseValidateWithContextAsync(
    const MiseValidationInput* input,
    MiseValidateRequestContextCallbackFunc requestContextCallback, void* callerContext,
    MiseValidationCompletionCallbackFunc completionCallback, void* completionNativeContext);

/**
 * @brief Asynchronously validates authentication with the Azure Authorization module enabled and a request context callback.
 *
 * The requestContextCallback is invoked synchronously before async validation begins, allowing the caller to set authorization payloads.
 * The completionCallback is invoked exactly once on a threadpool thread when validation completes (success or failure).
 * The caller must free the result via MiseFreeValidationResult.
 *
 * @param input - The input headers structured as `MiseValidationInput`.
 * @param requestContextCallback - The callback function that will receive request context (invoked synchronously).
 * @param callerContext - Optional: An opaque object that will be returned as the second parameter in the requestContextCallback.
 * @param completionCallback - The callback function invoked with the validation result upon completion.
 * @param completionNativeContext - Optional: A user-defined pointer to additional native context or state that will be passed to the completionCallback.
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseValidateWithAzureAuthorizationModuleAsync(
    const MiseValidationInput* input,
    MiseValidateRequestContextCallbackFunc requestContextCallback, void* callerContext,
    MiseValidationCompletionCallbackFunc completionCallback, void* completionNativeContext);

/**
 * @brief Asynchronously invokes a downstream API on behalf of the authenticated caller.
 *
 * The completionCallback is invoked exactly once on a threadpool thread when the API call completes (success or failure).
 * The caller must free the result via MiseFreeDownstreamApiResult.
 *
 * @param validationResult - Pointer to result structure from Validate.
 * @param input - Provides the necessary data for performing the downstream api request.
 * @param downstreamApiName - The name or identifier of the downstream API being called as defined in the 'DownstreamApi' configuration section.
 * @param completionCallback - The callback function invoked with the downstream API result upon completion.
 * @param nativeContext - Optional: A user-defined pointer to additional native context or state that will be passed to the callback.
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseCallDownstreamApiAsync(const MiseValidationResult* validationResult, const MiseDownstreamApiInput* input, const char* downstreamApiName,
    MiseDownstreamApiCompletionCallbackFunc completionCallback, void* nativeContext);

/**
 * @brief Asynchronously invokes a downstream API without prior authentication.
 *
 * The completionCallback is invoked exactly once on a threadpool thread when the API call completes (success or failure).
 * The caller must free the result via MiseFreeDownstreamApiResult.
 *
 * @param input - Provides the necessary data for performing the downstream api request.
 * @param downstreamApiName - The name or identifier of the downstream API being called as defined in the 'DownstreamApi' configuration section.
 * @param completionCallback - The callback function invoked with the downstream API result upon completion.
 * @param nativeContext - Optional: A user-defined pointer to additional native context or state that will be passed to the callback.
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseCallDownstreamApiUnauthenticatedAsync(const MiseDownstreamApiInput* input, const char* downstreamApiName,
    MiseDownstreamApiCompletionCallbackFunc completionCallback, void* nativeContext);

/**
 * @brief Asynchronously acquires an authentication token required to call a downstream API.
 *
 * The completionCallback is invoked exactly once on a threadpool thread when token acquisition completes (success or failure).
 * The caller must free the result via MiseFreeDownstreamAuthorizationHeaderResult.
 *
 * @param validationResult - Pointer to result structure from Validate.
 * @param input - Provides the necessary data for acquiring the authorization header.
 * @param downstreamApiName - The name or identifier of the downstream API being called as defined in the 'DownstreamApi' configuration section.
 * @param completionCallback - The callback function invoked with the authorization header result upon completion.
 * @param nativeContext - Optional: A user-defined pointer to additional native context or state that will be passed to the callback.
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseGetAuthorizationHeaderAsync(const MiseValidationResult* validationResult, const MiseDownstreamAuthorizationHeaderInput* input, const char* downstreamApiName,
    MiseGetAuthorizationHeaderCompletionCallbackFunc completionCallback, void* nativeContext);

/**
 * @brief Asynchronously acquires an authentication token required to call a downstream API without prior authentication.
 *
 * The completionCallback is invoked exactly once on a threadpool thread when token acquisition completes (success or failure).
 * The caller must free the result via MiseFreeDownstreamAuthorizationHeaderResult.
 *
 * @param input - Provides the necessary data for acquiring the authorization header.
 * @param downstreamApiName - The name or identifier of the downstream API being called as defined in the 'DownstreamApi' configuration section.
 * @param completionCallback - The callback function invoked with the authorization header result upon completion.
 * @param nativeContext - Optional: A user-defined pointer to additional native context or state that will be passed to the callback.
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseGetAuthorizationHeaderUnauthenticatedAsync(const MiseDownstreamAuthorizationHeaderInput* input, const char* downstreamApiName,
    MiseGetAuthorizationHeaderCompletionCallbackFunc completionCallback, void* nativeContext);

/**
 * @brief Frees up memory allocated for the MiseControlResult.
 *
 * @param result - pointer to result structure to free the memory for.
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseFreeControlResult(const MiseControlResult* result);

/**
 * @brief Frees up memory allocated for the MiseValidationResult.
 *
 * @param result - pointer to result structure to free the memory for.
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseFreeValidationResult(const MiseValidationResult* result);

/**
 * @brief Frees up memory allocated for the MiseDownstreamApiResult.
 *
 * @param result - pointer to result structure to free the memory for.
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseFreeDownstreamApiResult(const MiseDownstreamApiResult* result);

/**
 * @brief Frees up memory allocated for the MiseDownstreamAuthorizationHeaderResult.
 *
 * @param result - pointer to result structure to free the memory for.
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseFreeDownstreamAuthorizationHeaderResult(const MiseDownstreamAuthorizationHeaderResult* result);

/**
 * @brief Frees up memory allocated for the MiseDownstreamAuthorizationHeaderResult.
 *
 * @param result - pointer to callback context structure to free the memory for.
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseFreeLogMessageCallbackContext(const MiseLogMessageCallbackContext* context);

/**
 * @brief [DEPRECATED] Previously freed memory allocated for the NativeL2CacheGetDataCallbackContext.
 *
 * The managed runtime now owns the callback context and frees it automatically after the
 * native callback returns. This function is retained for binary compatibility but is a no-op.
 * Native callbacks must NOT call this function — doing so was required in older versions
 * but is no longer necessary.
 *
 * @param context - pointer to callback context structure (ignored).
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseFreeL2CacheGetDataCallbackContext(const NativeL2CacheGetDataCallbackContext* context);

/**
 * @brief [DEPRECATED] Previously freed memory allocated for the NativeL2CacheSetDataCallbackContext.
 *
 * The managed runtime now owns the callback context and frees it automatically after the
 * native callback returns. This function is retained for binary compatibility but is a no-op.
 * Native callbacks must NOT call this function — doing so was required in older versions
 * but is no longer necessary.
 *
 * @param context - pointer to callback context structure (ignored).
 */
MISE_EXTERN_C MISE_API void MISE_CALLTYPE MiseFreeL2CacheSetDataCallbackContext(const NativeL2CacheSetDataCallbackContext* context);

// FFI END

// Helpers for C++
#ifdef __cplusplus

#ifdef MISE_WINDOWS
#include <combaseapi.h>
#include <wincrypt.h>
#endif // MISE_WINDOWS
#ifdef MISE_LINUX
#include <stdlib.h>
#endif //  MISE_LINUX

#include <memory>

namespace Mise {
    template<typename T>
    struct CoTaskMemDeleter {
        void operator()(T* ptr) const {
            if (ptr) {
#ifdef MISE_WINDOWS
                ::CoTaskMemFree((void*)ptr);
#endif // MISE_WINDOWS
#ifdef MISE_LINUX
                free((void*)ptr);
#endif // MISE_LINUX
            }
        }
    };

    /**
      * @brief A RAII wrapper for Mise Results
      *
      * No need to manually release the memory allocated for the result pointer when wrapping in this smart ptr.
      */
    template<typename T>
    using ResultPtr = const std::unique_ptr<const T, CoTaskMemDeleter<const T>>;
}
#endif // __cplusplus

#endif // MISE_NATIVE_DLL_H
