from importlib import resources
from dataclasses import dataclass
import ctypes
import os
import platform
import sys
import threading
from concurrent.futures import Future
from enum import Enum
from contextlib import contextmanager
from cffi import FFI

FFI_BROKER = None
MISE_LIBRARY = None
# Guards one-time creation of the process-wide FFI instance and native library binding.
_FFI_INIT_LOCK = threading.Lock()

@contextmanager
def manage_result(lib, result, free_func_name):
    try:
        yield result
    finally:
        free_func = getattr(lib, free_func_name)
        free_func(result.data)

def _safe_set_exception(future, exc):
    """
    Set an exception on a future, tolerating the case where the future has already been
    completed or cancelled. Used by async completion callbacks so that a late/duplicate
    completion never propagates an exception back into native (cffi) callback code.
    """
    try:
        future.set_exception(exc)
    except Exception:
        pass

@dataclass
class MiseLogLevel(Enum):
    """
     Defines logging severity levels.
     Logging severity can be set through your config file's logging section.
    """

    Trace = 1        # Logs that contain the most detailed messages. These messages may contain sensitive application data.
    Debug = 2        # Logs that are used for interactive investigation during development.
    Information = 3  # Logs that track the general flow of the application.
    Warning = 4      # Logs that highlight an abnormal or unexpected event in the application flow.
    Error = 5        # Logs that highlight when the current flow of execution is stopped due to a failure.
    Critical = 6     # Logs that describe an unrecoverable application or system crash.
    NoneLevel = 7    # Not used for writing log messages.

class AccessDecision(Enum):
    """
    Defines Access Decisions.
    Access decisions returned by the Azure Authorization Module.
    """

    NotAllowed = 0
    Allowed = 1
    Denied = 2

@dataclass
class MiseErrorCode(Enum):
    """
    MISE error codes corresponding to MiseErrorCode enum in MiseDll.h
    """
    
    NONE = 0
    OTHER = 1
    TOKEN_NOT_YET_VALID = 2
    TOKEN_EXPIRED = 3
    MISSING_EXPIRATION_TIME = 4
    NOT_BEFORE_AFTER_EXPIRES = 5
    INVALID_AUDIENCE = 6
    INVALID_ISSUER = 7
    INVALID_SIGNATURE = 8
    INVALID_TOKEN_FORMAT = 9
    MISSING_SIGNING_TOKEN = 10

class MiseErrorEntry:
    """
    Error entry details corresponding to MiseErrorEntry struct in MiseDll.h
    """

    def __init__(self, ffi_data=None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseErrorEntry*")
        else:
            self._data = ffi_data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def error_type(self) -> str:
        """The error type string (e.g., IDX10500)."""
        return FFI_BROKER.string(self._data.errorType).decode('utf-8') if self._data.errorType != FFI_BROKER.NULL else None

    @error_type.setter
    def error_type(self, value: str) -> None:
        if value is None:
            self._data.errorType = FFI_BROKER.NULL
            return

        self._error_type = value
        self._error_type_utf8 = self._error_type.encode('utf-8')
        self._error_type_cffi = FFI_BROKER.new('char[]', self._error_type_utf8)
        self._data.errorType = self._error_type_cffi

    @property
    def error_code(self) -> MiseErrorCode:
        """The error code (MiseErrorCode enum)."""
        try:
            return MiseErrorCode(self._data.errorCode)
        except ValueError:
            return MiseErrorCode.OTHER

    @error_code.setter
    def error_code(self, value: MiseErrorCode) -> None:
        self._data.errorCode = value.value

    @property
    def error_message(self) -> str:
        """The full error message."""
        return FFI_BROKER.string(self._data.errorMessage).decode('utf-8') if self._data.errorMessage != FFI_BROKER.NULL else None

    @error_message.setter
    def error_message(self, value: str) -> None:
        if value is None:
            self._data.errorMessage = FFI_BROKER.NULL
            return

        self._error_message = value
        self._error_message_utf8 = self._error_message.encode('utf-8')
        self._error_message_cffi = FFI_BROKER.new('char[]', self._error_message_utf8)
        self._data.errorMessage = self._error_message_cffi

class MiseLogMessageCallbackContext:
    """
    This structure will be filled out by MISE and passed to your assigned log callback function.
    """

    def __init__(self, ffi_data=None):
        # Only native (MISE-allocated) memory may be released via MiseFree*. Memory that
        # cffi allocates for empty-constructed wrappers is owned by cffi and must not be
        # passed to MiseFree* (cross-allocator/double free) — cffi reclaims it on GC.
        self._owns_native = ffi_data is not None
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseLogMessageCallbackContext*")
        else:
            self._data = ffi_data

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self._owns_native and self._data is not None:
            MISE_LIBRARY.MiseFreeLogMessageCallbackContext(self._data)
            self._data = None

    def __del__(self):
        # During interpreter shutdown module globals may already be torn down to None;
        # capture a local ref and guard to avoid noisy "Exception ignored in __del__".
        lib = MISE_LIBRARY
        if lib is not None and getattr(self, '_owns_native', False) and self._data is not None:
            lib.MiseFreeLogMessageCallbackContext(self._data)
            self._data = None

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def message(self) -> str:
        return FFI_BROKER.string(self._data.message).decode('utf-8') if self._data.message != FFI_BROKER.NULL else None

    @message.setter
    def message(self, value: str) -> None:
        if value is None:
            self._data.message = FFI_BROKER.NULL
            return

        self._native_message = value
        self._native_message_utf8 = self._native_message.encode('utf-8')
        self._native_message_cffi = FFI_BROKER.new('char[]', self._native_message_utf8)
        self._data.message = self._native_message_cffi

    @property
    def level(self) -> MiseLogLevel:
        if self._data.level == FFI_BROKER.NULL:
            return None
        return MiseLogLevel(self._data.level)

    @level.setter
    def level(self, value: MiseLogLevel) -> None:
        self._data.level = value.value

class MiseControlResult:
    """
    Result structure for MISE control functions.
    This structure contains result values from MISE control functions.
    """

    def __init__(self, ffi_data=None):
        # Only native (MISE-allocated) memory may be released via MiseFree*. Memory that
        # cffi allocates for empty-constructed wrappers is owned by cffi and must not be
        # passed to MiseFree* (cross-allocator/double free) — cffi reclaims it on GC.
        self._owns_native = ffi_data is not None
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseControlResult*")
        else:
            self._data = ffi_data

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self._owns_native and self._data is not None:
            MISE_LIBRARY.MiseFreeControlResult(self._data)
            self._data = None

    def __del__(self):
        # During interpreter shutdown module globals may already be torn down to None;
        # capture a local ref and guard to avoid noisy "Exception ignored in __del__".
        lib = MISE_LIBRARY
        if lib is not None and getattr(self, '_owns_native', False) and self._data is not None:
            lib.MiseFreeControlResult(self._data)
            self._data = None

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def error_code(self) -> int:
        """
        Gets or sets the error code representing the outcome of a MISE control function.
        Set 0 when the operation was successful.
        """
        return self._data.errorCode

    @error_code.setter
    def error_code(self, value: int) -> None:
        self._data.errorCode = value

    @property
    def error_description(self) -> str:
        """
        Gets or sets the description of the error, if any.
        """
        return FFI_BROKER.string(self._data.errorDescription).decode('utf-8') if self._data.errorDescription != FFI_BROKER.NULL else None

    @error_description.setter
    def error_description(self, value: str) -> None:
        if value is None:
            self._data.errorDescription = FFI_BROKER.NULL
            return

        self._error_description = value
        self._error_description_utf8 = self._error_description.encode('utf-8')
        self._error_description_cffi = FFI_BROKER.new('char[]', self._error_description_utf8)
        self._data.errorDescription = self._error_description_cffi

class MiseClaim:
    """
    Structure for token claims. This structure describes a claim. MiseNativeClaim was renamed to MiseClaim
    """

    def __init__(self, ffi_data = None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseClaim*")
        else:
            self._data = ffi_data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def name(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.name).decode('utf-8') if self._data.name != FFI_BROKER.NULL else None
        return res

    @name.setter
    def name(self, value) -> str:
        if value is None:
            self._data.name = FFI_BROKER.NULL
            return

        self._name = value
        self._name_utf8 = self._name.encode('utf-8')
        self._name_cffi = FFI_BROKER.new('char[]', self._name_utf8)
        self._data.name = self._name_cffi

    @property
    def value(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.value).decode('utf-8') if self._data.value != FFI_BROKER.NULL else None
        return res

    @value.setter
    def value(self, value) -> str:
        if value is None:
            self._data.value = FFI_BROKER.NULL
            return

        self._value = value
        self._value_utf8 = self._value.encode('utf-8')
        self._value_cffi = FFI_BROKER.new('char[]', self._value_utf8)
        self._data.value = self._value_cffi

class MiseRequestHeader:
    """
    Structure for additional request headers. This structure describes a request header.
    """

    def __init__(self, ffi_data = None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseRequestHeader*")
        else:
            self._data = ffi_data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def name(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.name).decode('utf-8') if self._data.name != FFI_BROKER.NULL else None
        return res

    @name.setter
    def name(self, value) -> str:
        if value is None:
            self._data.name = FFI_BROKER.NULL
            return

        self._name = value
        self._name_utf8 = self._name.encode('utf-8')
        self._name_cffi = FFI_BROKER.new('char[]', self._name_utf8)
        self._data.name = self._name_cffi

    @property
    def value(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.value).decode('utf-8') if self._data.value != FFI_BROKER.NULL else None
        return res

    @value.setter
    def value(self, value) -> str:
        if value is None:
            self._data.value = FFI_BROKER.NULL
            return

        self._value = value
        self._value_utf8 = self._value.encode('utf-8')
        self._value_cffi = FFI_BROKER.new('char[]', self._value_utf8)
        self._data.value = self._value_cffi

class MiseAuthorizationResponseResult:
    """
    Structure for Azure Authorization Module authorization response.
    This structure describes an authorization response.
    """

    def __init__(self, ffi_data=None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseAuthorizationResponseResult*")
        else:
            self._data = ffi_data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def access_decision(self) -> AccessDecision:
        return AccessDecision(self._data.AccessDecision)

    @access_decision.setter
    def access_decision(self, value: AccessDecision) -> None:
        self._data.AccessDecision = value.value

    @property
    def action_id(self) -> str:
        return FFI_BROKER.string(self._data.ActionId).decode('utf-8') if self._data.ActionId != FFI_BROKER.NULL else None

    @action_id.setter
    def action_id(self, value: str) -> None:
        if value is None:
            self._data.ActionId = FFI_BROKER.NULL
            return

        self._action_id = value
        self._action_id_utf8 = self._action_id.encode('utf-8')
        self._action_id_cffi = FFI_BROKER.new('char[]', self._action_id_utf8)
        self._data.ActionId = self._action_id_cffi

    @property
    def is_data_action(self) -> bool:
        return self._data.IsDataAction

    @is_data_action.setter
    def is_data_action(self, value: bool) -> None:
        self._data.IsDataAction = value

    @property
    def role_assignment(self) -> str:
        return FFI_BROKER.string(self._data.RoleAssignment).decode('utf-8') if self._data.RoleAssignment != FFI_BROKER.NULL else None

    @role_assignment.setter
    def role_assignment(self, value: str) -> None:
        if value is None:
            self._data.RoleAssignment = FFI_BROKER.NULL
            return

        self._role_assignment = value
        self._role_assignment_utf8 = self._role_assignment.encode('utf-8')
        self._role_assignment_cffi = FFI_BROKER.new('char[]', self._role_assignment_utf8)
        self._data.RoleAssignment = self._role_assignment_cffi

    @property
    def deny_assignment(self) -> str:
        return FFI_BROKER.string(self._data.DenyAssignment).decode('utf-8') if self._data.DenyAssignment != FFI_BROKER.NULL else None

    @deny_assignment.setter
    def deny_assignment(self, value: str) -> None:
        if value is None:
            self._data.DenyAssignment = FFI_BROKER.NULL
            return

        self._deny_assignment = value
        self._deny_assignment_utf8 = self._deny_assignment.encode('utf-8')
        self._deny_assignment_cffi = FFI_BROKER.new('char[]', self._deny_assignment_utf8)
        self._data.DenyAssignment = self._deny_assignment_cffi

    @property
    def time_to_live_in_ms(self) -> int:
        return self._data.TimeToLiveInMs

    @time_to_live_in_ms.setter
    def time_to_live_in_ms(self, value: int) -> None:
        self._data.TimeToLiveInMs = value

class MiseAuthorizationPoliciesResult:
    """
    Structure for Azure Authorization Module authorization policy.
    This structure describes an authorization policy.
    """

    def __init__(self, ffi_data=None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseAuthorizationPoliciesResult*")
        else:
            self._data = ffi_data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def role_assignments(self) -> str:
        return FFI_BROKER.string(self._data.RoleAssignments).decode('utf-8') if self._data.RoleAssignments != FFI_BROKER.NULL else None

    @role_assignments.setter
    def role_assignments(self, value: str) -> None:
        if value is None:
            self._data.RoleAssignments = FFI_BROKER.NULL
            return

        self._role_assignments = value
        self._role_assignments_utf8 = self._role_assignments.encode('utf-8')
        self._role_assignments_cffi = FFI_BROKER.new('char[]', self._role_assignments_utf8)
        self._data.RoleAssignments = self._role_assignments_cffi

    @property
    def role_definitions(self) -> str:
        return FFI_BROKER.string(self._data.RoleDefinitions).decode('utf-8') if self._data.RoleDefinitions != FFI_BROKER.NULL else None

    @role_definitions.setter
    def role_definitions(self, value: str) -> None:
        if value is None:
            self._data.RoleDefinitions = FFI_BROKER.NULL
            return

        self._role_definitions = value
        self._role_definitions_utf8 = self._role_definitions.encode('utf-8')
        self._role_definitions_cffi = FFI_BROKER.new('char[]', self._role_definitions_utf8)
        self._data.RoleDefinitions = self._role_definitions_cffi

    @property
    def deny_assignments(self) -> str:
        return FFI_BROKER.string(self._data.DenyAssignments).decode('utf-8') if self._data.DenyAssignments != FFI_BROKER.NULL else None

    @deny_assignments.setter
    def deny_assignments(self, value: str) -> None:
        if value is None:
            self._data.DenyAssignments = FFI_BROKER.NULL
            return

        self._deny_assignments = value
        self._deny_assignments_utf8 = self._deny_assignments.encode('utf-8')
        self._deny_assignments_cffi = FFI_BROKER.new('char[]', self._deny_assignments_utf8)
        self._data.DenyAssignments = self._deny_assignments_cffi

    @property
    def principal_groups(self) -> str:
        return FFI_BROKER.string(self._data.PrincipalGroups).decode('utf-8') if self._data.PrincipalGroups != FFI_BROKER.NULL else None

    @principal_groups.setter
    def principal_groups(self, value: str) -> None:
        if value is None:
            self._data.PrincipalGroups = FFI_BROKER.NULL
            return

        self._principal_groups = value
        self._principal_groups_utf8 = self._principal_groups.encode('utf-8')
        self._principal_groups_cffi = FFI_BROKER.new('char[]', self._principal_groups_utf8)
        self._data.PrincipalGroups = self._principal_groups_cffi

    @property
    def time_to_live_in_ms(self) -> int:
        return self._data.TimeToLiveInMs

    @time_to_live_in_ms.setter
    def time_to_live_in_ms(self, value: int) -> None:
        self._data.TimeToLiveInMs = value

class MiseAppSwitchesInput:
    """
    Input structure for Application Switches for the MiseConfigure function.
    This structure is used to encapsulate input values passed to the MiseConfigure function.
    """

    def __init__(self, ffi_data=None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseAppSwitchesInput*")
        else:
            self._data = ffi_data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def switches(self) -> list[str]:
        if self._data.switches == FFI_BROKER.NULL or self._data.switchCount == 0:
            return []
        return [FFI_BROKER.string(self._data.switches[i]).decode('utf-8') for i in range(self._data.switchCount)]

    @switches.setter
    def switches(self, value: list[str]) -> None:
        if value is None or len(value) == 0:
            self._data.switches = FFI_BROKER.NULL
            self._data.switchCount = 0
            return

        self._switches_list = value
        self._switches_utf8 = [s.encode('utf-8') for s in value]
        self._switches_cffi = [FFI_BROKER.new('char[]', s) for s in self._switches_utf8]
        self._switches_array = FFI_BROKER.new('char*[]', self._switches_cffi)
        self._data.switches = self._switches_array
        self._data.switchCount = len(value)

class NativeL2CacheGetDataCallbackContext:
    """
    Context for L2 cache get data callback.
    This structure will be filled out by MISE and passed to your assigned callback function.
    """

    def __init__(self, ffi_data=None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("NativeL2CacheGetDataCallbackContext*")
        else:
            self._data = ffi_data

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        # No-op: the managed runtime now owns and frees the callback context automatically.
        pass

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def key(self) -> str:
        return FFI_BROKER.string(self._data.key).decode('utf-8') if self._data.key != FFI_BROKER.NULL else None

    @key.setter
    def key(self, value: str) -> None:
        if value is None:
            self._data.key = FFI_BROKER.NULL
            self._data.keySize = 0
            return

        self._key = value
        self._key_utf8 = self._key.encode('utf-8')
        self._key_cffi = FFI_BROKER.new('char[]', self._key_utf8)
        self._data.key = self._key_cffi
        self._data.keySize = len(self._key_utf8)

    @property
    def key_size(self) -> int:
        return self._data.keySize

class NativeL2CacheSetDataCallbackContext:
    """
    Context for L2 cache set data callback.
    This structure will be filled out by MISE and passed to your assigned callback function.
    """

    def __init__(self, ffi_data=None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("NativeL2CacheSetDataCallbackContext*")
        else:
            self._data = ffi_data

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        # No-op: the managed runtime now owns and frees the callback context automatically.
        pass

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def key(self) -> str:
        return FFI_BROKER.string(self._data.key).decode('utf-8') if self._data.key != FFI_BROKER.NULL else None

    @key.setter
    def key(self, value: str) -> None:
        if value is None:
            self._data.key = FFI_BROKER.NULL
            self._data.keySize = 0
            return

        self._key = value
        self._key_utf8 = self._key.encode('utf-8')
        self._key_cffi = FFI_BROKER.new('char[]', self._key_utf8)
        self._data.key = self._key_cffi
        self._data.keySize = len(self._key_utf8)

    @property
    def cache_data(self) -> str:
        return FFI_BROKER.string(self._data.data).decode('utf-8') if self._data.data != FFI_BROKER.NULL else None

    @cache_data.setter
    def cache_data(self, value: str) -> None:
        if value is None:
            self._data.data = FFI_BROKER.NULL
            self._data.dataSize = 0
            return

        self._cache_data = value
        self._cache_data_utf8 = self._cache_data.encode('utf-8')
        self._cache_data_cffi = FFI_BROKER.new('char[]', self._cache_data_utf8)
        self._data.data = self._cache_data_cffi
        self._data.dataSize = len(self._cache_data_utf8)

    @property
    def key_size(self) -> int:
        return self._data.keySize

    @property
    def data_size(self) -> int:
        return self._data.dataSize

    @property
    def absolute_expiration_relative_to_now_in_seconds(self) -> int:
        return self._data.absoluteExpirationRelativeToNowInSeconds

    @absolute_expiration_relative_to_now_in_seconds.setter
    def absolute_expiration_relative_to_now_in_seconds(self, value: int) -> None:
        self._data.absoluteExpirationRelativeToNowInSeconds = value

class MiseL2CacheGetDataCallbackResult:
    """
    Result structure for retrieving OIDC metadata from a distributed cache.
    """

    def __init__(self, ffi_data=None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseL2CacheGetDataCallbackResult*")
        else:
            self._data = ffi_data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def cache_data(self) -> str:
        return FFI_BROKER.string(self._data.data).decode('utf-8') if self._data.data != FFI_BROKER.NULL else None

    @cache_data.setter
    def cache_data(self, value: str) -> None:
        if value is None:
            self._data.data = FFI_BROKER.NULL
            self._data.dataSize = 0
            return

        self._cache_data = value
        self._cache_data_utf8 = self._cache_data.encode('utf-8')
        self._cache_data_cffi = FFI_BROKER.new('char[]', self._cache_data_utf8)
        self._data.data = self._cache_data_cffi
        self._data.dataSize = len(self._cache_data_utf8)

    @property
    def data_size(self) -> int:
        return self._data.dataSize

    @property
    def error_code(self) -> int:
        return self._data.errorCode

    @error_code.setter
    def error_code(self, value: int) -> None:
        self._data.errorCode = value

class MiseL2CacheSetDataCallbackResult:
    """
    Result structure for storing OIDC metadata to a distributed cache.
    """

    def __init__(self, ffi_data=None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseL2CacheSetDataCallbackResult*")
        else:
            self._data = ffi_data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def error_code(self) -> int:
        return self._data.errorCode

    @error_code.setter
    def error_code(self, value: int) -> None:
        self._data.errorCode = value

class MiseValidationInput:
    """

    """

    def __init__(self, ffi_data = None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseValidationInput*")
        else:
            self._data = ffi_data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def authorization_header(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.authorizationHeader).decode('utf-8') if self._data.authorizationHeader != FFI_BROKER.NULL else None
        return res

    @authorization_header.setter
    def authorization_header(self, value) -> str:
        if value is None:
            self._data.authorizationHeader = FFI_BROKER.NULL
            return

        self._authorization_header = value
        self._authorization_header_utf8 = self._authorization_header.encode('utf-8')
        self._authorization_header_cffi = FFI_BROKER.new('char[]', self._authorization_header_utf8)
        self._data.authorizationHeader = self._authorization_header_cffi

    @property
    def x_forwarded_for_header(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.xForwardedForHeader).decode('utf-8') if self._data.xForwardedForHeader != FFI_BROKER.NULL else None
        return res

    @x_forwarded_for_header.setter
    def x_forwarded_for_header(self, value) -> str:
        if value is None:
            self._data.xForwardedForHeader = FFI_BROKER.NULL
            return

        self._xforwarded_for_header = value
        self._xforwarded_for_header_utf8 = self._xforwarded_for_header.encode('utf-8')
        self._xforwarded_for_header_cffi = FFI_BROKER.new('char[]', self._xforwarded_for_header_utf8)
        self._data.xForwardedForHeader = self._xforwarded_for_header_cffi

    @property
    def original_uri_header(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.originalUriHeader).decode('utf-8') if self._data.originalUriHeader != FFI_BROKER.NULL else None
        return res

    @original_uri_header.setter
    def original_uri_header(self, value) -> str:
        if value is None:
            self._data.originalUriHeader = FFI_BROKER.NULL
            return

        self._original_uri_header = value
        self._original_uri_header_utf8 = self._original_uri_header.encode('utf-8')
        self._original_uri_header_cffi = FFI_BROKER.new('char[]', self._original_uri_header_utf8)
        self._data.originalUriHeader = self._original_uri_header_cffi

    @property
    def original_method_header(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.originalMethodHeader).decode('utf-8') if self._data.originalMethodHeader != FFI_BROKER.NULL else None
        return res

    @original_method_header.setter
    def original_method_header(self, value) -> str:
        if value is None:
            self._data.originalMethodHeader = FFI_BROKER.NULL
            return

        self._original_method_header = value
        self._original_method_header_utf8 = self._original_method_header.encode('utf-8')
        self._original_method_header_cffi = FFI_BROKER.new('char[]', self._original_method_header_utf8)
        self._data.originalMethodHeader = self._original_method_header_cffi

    @property
    def mise_correlation_id(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.miseCorrelationId).decode('utf-8') if self._data.miseCorrelationId != FFI_BROKER.NULL else None
        return res

    @mise_correlation_id.setter
    def mise_correlation_id(self, value) -> str:
        if value is None:
            self._data.miseCorrelationId = FFI_BROKER.NULL
            return

        self._mise_correlation_id = value
        self._mise_correlation_id_utf8 = self._mise_correlation_id.encode('utf-8')
        self._mise_correlation_id_cffi = FFI_BROKER.new('char[]', self._mise_correlation_id_utf8)
        self._data.miseCorrelationId = self._mise_correlation_id_cffi

    @property
    def additional_header_values(self) -> list:
        """
        Get the additional header values as a list of MiseRequestHeader objects.
        """
        if self._data.additionalHeaderValues == FFI_BROKER.NULL or self._data.additionalHeaderValuesCount == 0:
            return []

        header_list = []
        for i in range(self._data.additionalHeaderValuesCount):
            header = self._data.additionalHeaderValues[i]
            header_obj = MiseRequestHeader(header)
            header_list.append(header_obj)

        return header_list

    @additional_header_values.setter
    def additional_header_values(self, value: list) -> None:
        """
        Set the additional header values from a list of MiseRequestHeader objects.
        """
        if value is None or len(value) == 0:
            self._data.additionalHeaderValues = FFI_BROKER.NULL
            self._data.additionalHeaderValuesCount = 0
            return

        # Create an array of MiseRequestHeader structs
        self._additional_header_values_count = len(value)
        self._additional_header_values_array = FFI_BROKER.new(f"MiseRequestHeader[{self._additional_header_values_count}]")

        for i, header in enumerate(value):
            if isinstance(header, MiseRequestHeader):
                # Copy the data from the MiseRequestHeader object
                self._additional_header_values_array[i] = header.data[0]  # Dereference the pointer
            else:
                raise ValueError(f"Expected MiseRequestHeader object, got {type(header)}")

        self._data.additionalHeaderValues = self._additional_header_values_array
        self._data.additionalHeaderValuesCount = self._additional_header_values_count

    @property
    def additional_header_values_count(self) -> int:
        """
        Get the count of additional header values.
        """
        return self._data.additionalHeaderValuesCount

    @additional_header_values_count.setter
    def additional_header_values_count(self, value: int) -> None:
        """
        Set the count of additional header values.
        Note: This is automatically set when you assign additional_header_values.
        """
        self._data.additionalHeaderValuesCount = value

class MiseClaimsIdentityContext:
    """
    Optional flat snapshot of the inbound identity context needed for outbound token acquisition
    (notably MSAuth 1.0 AT_POP / MTLS_POP+CDT envelope construction). Returned via
    ``MiseValidationResult.claims_identity_context`` when populated; ``None`` for plain bearer / MSI flows.

    When read off a native ``MiseValidationResult``, this wrapper borrows the underlying buffer
    (co-allocated with the owning result) and is valid only for that result's lifetime.
    """

    def __init__(self, ffi_data=None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseClaimsIdentityContext*")
        else:
            self._data = ffi_data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def pft(self) -> str:
        """Raw PFT string used by MSAuth 1.0 AT_POP / MTLS_POP+CDT envelope construction. May be None."""
        return FFI_BROKER.string(self._data.pft).decode('utf-8') if self._data.pft != FFI_BROKER.NULL else None

    @pft.setter
    def pft(self, value: str) -> None:
        if value is None:
            self._data.pft = FFI_BROKER.NULL
            return
        self._pft = value
        self._pft_utf8 = self._pft.encode('utf-8')
        self._pft_cffi = FFI_BROKER.new('char[]', self._pft_utf8)
        self._data.pft = self._pft_cffi

    @property
    def cdt(self) -> str:
        """Raw CDT string. Mutually exclusive with `pft` on the envelope side. May be None."""
        return FFI_BROKER.string(self._data.cdt).decode('utf-8') if self._data.cdt != FFI_BROKER.NULL else None

    @cdt.setter
    def cdt(self, value: str) -> None:
        if value is None:
            self._data.cdt = FFI_BROKER.NULL
            return
        self._cdt = value
        self._cdt_utf8 = self._cdt.encode('utf-8')
        self._cdt_cffi = FFI_BROKER.new('char[]', self._cdt_utf8)
        self._data.cdt = self._cdt_cffi

    @property
    def tid(self) -> str:
        """Pre-resolved tenant id (CDT.tid -> Actor.tid -> Subject.tid cascade). May be None."""
        return FFI_BROKER.string(self._data.tid).decode('utf-8') if self._data.tid != FFI_BROKER.NULL else None

    @tid.setter
    def tid(self, value: str) -> None:
        if value is None:
            self._data.tid = FFI_BROKER.NULL
            return
        self._tid = value
        self._tid_utf8 = self._tid.encode('utf-8')
        self._tid_cffi = FFI_BROKER.new('char[]', self._tid_utf8)
        self._data.tid = self._tid_cffi


class MiseValidationResult:
    """
    Structure for validation result.
    """

    def __init__(self, ffi_data=None):
        # Only native (MISE-allocated) memory may be released via MiseFree*. Memory that
        # cffi allocates for empty-constructed wrappers is owned by cffi and must not be
        # passed to MiseFree* (cross-allocator/double free) — cffi reclaims it on GC.
        self._owns_native = ffi_data is not None
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseValidationResult*")
        else:
            self._data = ffi_data

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self._owns_native and self._data is not None:
            MISE_LIBRARY.MiseFreeValidationResult(self._data)
            self._data = None

    def __del__(self):
        # During interpreter shutdown module globals may already be torn down to None;
        # capture a local ref and guard to avoid noisy "Exception ignored in __del__".
        lib = MISE_LIBRARY
        if lib is not None and getattr(self, '_owns_native', False) and self._data is not None:
            lib.MiseFreeValidationResult(self._data)
            self._data = None

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def http_response_status_code(self) -> int:
        return self._data.httpResponseStatusCode

    @http_response_status_code.setter
    def http_response_status_code(self, value: int) -> None:
        self._httpResponseStatusCode = value
        self._data.httpResponseStatusCode = self._httpResponseStatusCode

    @property
    def correlation_id(self) -> str:
        return FFI_BROKER.string(self._data.correlationId).decode('utf-8') if self._data.correlationId != FFI_BROKER.NULL else None

    @correlation_id.setter
    def correlation_id(self, value: str) -> None:
        if value is None:
            self._data.correlationId = FFI_BROKER.NULL
            return

        self._correlation_id = value
        self._correlation_id_utf8 = self._correlation_id.encode('utf-8')
        self._correlation_id_cffi = FFI_BROKER.new('char[]', self._correlation_id_utf8)
        self._data.correlationId = self._correlation_id_cffi

    @property
    def error_description(self) -> str:
        return FFI_BROKER.string(self._data.errorDescription).decode('utf-8') if self._data.errorDescription != FFI_BROKER.NULL else None

    @error_description.setter
    def error_description(self, value: str) -> None:
        if value is None:
            self._data.errorDescription = FFI_BROKER.NULL
            return

        self._error_description = value
        self._error_description_utf8 = self._error_description.encode('utf-8')
        self._error_description_cffi = FFI_BROKER.new('char[]', self._error_description_utf8)
        self._data.errorDescription = self._error_description_cffi

    @property
    def www_authenticate(self) -> str:
        return FFI_BROKER.string(self._data.wwwAuthenticate).decode('utf-8') if self._data.wwwAuthenticate != FFI_BROKER.NULL else None

    @www_authenticate.setter
    def www_authenticate(self, value: str) -> None:
        if value is None:
            self._data.wwwAuthenticate = FFI_BROKER.NULL
            return

        self._www_authenticate = value
        self._www_authenticate_utf8 = self._www_authenticate.encode('utf-8')
        self._www_authenticate_cffi = FFI_BROKER.new('char[]', self._www_authenticate_utf8)
        self._data.wwwAuthenticate = self._www_authenticate_cffi

    @property
    def subject_token(self) -> str:
        return FFI_BROKER.string(self._data.subjectToken).decode('utf-8') if self._data.subjectToken != FFI_BROKER.NULL else None

    @subject_token.setter
    def subject_token(self, value: str) -> None:
        if value is None:
            self._data.subjectToken = FFI_BROKER.NULL
            return

        self._subject_token = value
        self._subject_token_utf8 = self._subject_token.encode('utf-8')
        self._subject_token_cffi = FFI_BROKER.new('char[]', self._subject_token_utf8)
        self._data.subjectToken = self._subject_token_cffi

    @property
    def subject_token_type(self) -> str:
        return FFI_BROKER.string(self._data.subjectTokenType).decode('utf-8') if self._data.subjectTokenType != FFI_BROKER.NULL else None

    @subject_token_type.setter
    def subject_token_type(self, value: str) -> None:
        if value is None:
            self._data.subjectTokenType = FFI_BROKER.NULL
            return

        self._subject_token_type = value
        self._subject_token_type_utf8 = self._subject_token_type.encode('utf-8')
        self._subject_token_type_cffi = FFI_BROKER.new('char[]', self._subject_token_type_utf8)
        self._data.subjectTokenType = self._subject_token_type_cffi

    @property
    def actor_token(self) -> str:
        return FFI_BROKER.string(self._data.actorToken).decode('utf-8') if self._data.actorToken != FFI_BROKER.NULL else None

    @actor_token.setter
    def actor_token(self, value: str) -> None:
        if value is None:
            self._data.actorToken = FFI_BROKER.NULL
            return

        self._actor_token = value
        self._actor_token_utf8 = self._actor_token.encode('utf-8')
        self._actor_token_cffi = FFI_BROKER.new('char[]', self._actor_token_utf8)
        self._data.actorToken = self._actor_token_cffi

    @property
    def pop_server_nonce(self) -> str:
        return FFI_BROKER.string(self._data.popServerNonce).decode('utf-8') if self._data.popServerNonce != FFI_BROKER.NULL else None

    @pop_server_nonce.setter
    def pop_server_nonce(self, value: str) -> None:
        if value is None:
            self._data.popServerNonce = FFI_BROKER.NULL
            return

        self._pop_server_nonce = value
        self._pop_server_nonce_utf8 = self._pop_server_nonce.encode('utf-8')
        self._pop_server_nonce_cffi = FFI_BROKER.new('char[]', self._pop_server_nonce_utf8)
        self._data.popServerNonce = self._pop_server_nonce_cffi

    @property
    def authentication_scheme(self) -> str:
        return FFI_BROKER.string(self._data.authenticationScheme).decode('utf-8') if self._data.authenticationScheme != FFI_BROKER.NULL else None

    @authentication_scheme.setter
    def authentication_scheme(self, value: str) -> None:
        if value is None:
            self._data.authenticationScheme = FFI_BROKER.NULL
            return

        self._authentication_scheme = value
        self._authentication_scheme_utf8 = self._authentication_scheme.encode('utf-8')
        self._authentication_scheme_cffi = FFI_BROKER.new('char[]', self._authentication_scheme_utf8)
        self._data.authenticationScheme = self._authentication_scheme_cffi

    @property
    def subject_claims(self) -> list[MiseClaim]:
        return [MiseClaim(self._data.subjectClaims[i]) for i in range(self._data.subjectClaimsCount)]

    @subject_claims.setter
    def subject_claims(self, value: list[MiseClaim]) -> None:
        pass

    @property
    def subject_claims_count(self) -> int:
        return self._data.subjectClaimsCount

    @subject_claims_count.setter
    def subject_claims_count(self, value: int) -> None:
        self._data.subjectClaimsCount = value

    @property
    def actor_claims(self) -> list[MiseClaim]:
        return [MiseClaim(self._data.actorClaims[i]) for i in range(self._data.actorClaimsCount)]

    @actor_claims.setter
    def actor_claims(self, value: list[MiseClaim]) -> None:
        pass

    @property
    def actor_claims_count(self) -> int:
        return self._data.actorClaimsCount

    @actor_claims_count.setter
    def actor_claims_count(self, value: int) -> None:
        self._data.actorClaimsCount = value

    @property
    def authorization_response_count(self) -> int:
        """Number of Azure Authorization decisions returned for this request.

        Typically 0 (token validated without an authorization check) or 1
        (authorization was requested and the PDP returned a decision).
        When this value is >= 1, ``authorization_response`` is non-None and
        contains the first decision (access_decision, action_id, etc.).
        """
        return self._data.authorizationResponseCount

    @authorization_response_count.setter
    def authorization_response_count(self, value: int) -> None:
        self._data.authorizationResponseCount = value

    @property
    def claims_identity_context(self) -> "MiseClaimsIdentityContext":
        """Optional flat outbound identity context (PFT/CDT/tid) populated for AT_POP flows.

        Returns ``None`` when the inbound flow produced no AT_POP context (the common case
        for plain bearer / MSI). When non-None, the returned wrapper borrows memory that is
        co-allocated with this validation result and freed together with it.
        """
        if self._data.claimsIdentityContext == FFI_BROKER.NULL:
            return None
        return MiseClaimsIdentityContext(self._data.claimsIdentityContext)

    @claims_identity_context.setter
    def claims_identity_context(self, value: "MiseClaimsIdentityContext") -> None:
        if value is None:
            self._data.claimsIdentityContext = FFI_BROKER.NULL
            return
        # Hold a reference so the backing CFFI buffer stays alive while the parent does.
        self._claims_identity_context = value
        self._data.claimsIdentityContext = value.data

    @property
    def authz_details_blob(self) -> str:
        return FFI_BROKER.string(self._data.authZDetailsBlob).decode('utf-8') if self._data.authZDetailsBlob != FFI_BROKER.NULL else None

    @authz_details_blob.setter
    def authz_details_blob(self, value: str) -> None:
        if value is None:
            self._data.authZDetailsBlob = FFI_BROKER.NULL
            return

        self._authz_details_blob = value
        self._authz_details_blob_utf8 = self._authz_details_blob.encode('utf-8')
        self._authz_details_blob_cffi = FFI_BROKER.new('char[]', self._authz_details_blob_utf8)
        self._data.authZDetailsBlob = self._authz_details_blob_cffi

    @property
    def authorization_policies(self):
        """Authorization policies, if any and requested."""
        if self._data.authorizationPolicies == FFI_BROKER.NULL:
            return None
        return MiseAuthorizationPoliciesResult(self._data.authorizationPolicies)

    @authorization_policies.setter
    def authorization_policies(self, value) -> None:
        raise AttributeError("authorization_policies is read-only; it is populated by MISE after validation.")

    @property
    def authorization_response(self):
        """Authorization response, if successful and requested."""
        if self._data.authorizationResponse == FFI_BROKER.NULL:
            return None
        return MiseAuthorizationResponseResult(self._data.authorizationResponse)

    @authorization_response.setter
    def authorization_response(self, value) -> None:
        raise AttributeError("authorization_response is read-only; it is populated by MISE after validation.")

    @property
    def errors(self) -> list[MiseErrorEntry]:
        """Error details parsed from error description, if any."""
        if self._data.errors == FFI_BROKER.NULL or self._data.errorCount == 0:
            return []
        return [MiseErrorEntry(self._data.errors[i]) for i in range(self._data.errorCount)]

    @errors.setter
    def errors(self, value: list[MiseErrorEntry]) -> None:
        pass

    @property
    def error_count(self) -> int:
        """Error details count."""
        return self._data.errorCount

    @error_count.setter
    def error_count(self, value: int) -> None:
        self._data.errorCount = value

class MiseDownstreamAuthorizationHeaderResult:
    """
    Container class for downstream authorization header results.
    """

    def __init__(self, ffi_data=None):
        # Only native (MISE-allocated) memory may be released via MiseFree*. Memory that
        # cffi allocates for empty-constructed wrappers is owned by cffi and must not be
        # passed to MiseFree* (cross-allocator/double free) — cffi reclaims it on GC.
        self._owns_native = ffi_data is not None
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseDownstreamAuthorizationHeaderResult*")
        else:
            self._data = ffi_data

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self._owns_native and self._data is not None:
            MISE_LIBRARY.MiseFreeDownstreamAuthorizationHeaderResult(self._data)
            self._data = None

    def __del__(self):
        # During interpreter shutdown module globals may already be torn down to None;
        # capture a local ref and guard to avoid noisy "Exception ignored in __del__".
        lib = MISE_LIBRARY
        if lib is not None and getattr(self, '_owns_native', False) and self._data is not None:
            lib.MiseFreeDownstreamAuthorizationHeaderResult(self._data)
            self._data = None

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def http_response_status_code(self) -> int:
        return self._data.httpResponseStatusCode

    @http_response_status_code.setter
    def http_response_status_code(self, value: int) -> None:
        self._data.httpResponseStatusCode = value

    @property
    def correlation_id(self) -> str:
        return FFI_BROKER.string(self._data.correlationId).decode('utf-8') if self._data.correlationId != FFI_BROKER.NULL else None

    @correlation_id.setter
    def correlation_id(self, value: str) -> None:
        if value is None:
            self._data.correlationId = FFI_BROKER.NULL
            return

        self._correlation_id = value
        self._correlation_id_utf8 = self._correlation_id.encode('utf-8')
        self._correlation_id_cffi = FFI_BROKER.new('char[]', self._correlation_id_utf8)
        self._data.correlationId = self._correlation_id_cffi

    @property
    def error_description(self) -> str:
        return FFI_BROKER.string(self._data.errorDescription).decode('utf-8') if self._data.errorDescription != FFI_BROKER.NULL else None

    @error_description.setter
    def error_description(self, value: str) -> None:
        if value is None:
            self._data.errorDescription = FFI_BROKER.NULL
            return

        self._error_description = value
        self._error_description_utf8 = self._error_description.encode('utf-8')
        self._error_description_cffi = FFI_BROKER.new('char[]', self._error_description_utf8)
        self._data.errorDescription = self._error_description_cffi

    @property
    def www_authenticate(self) -> str:
        return FFI_BROKER.string(self._data.wwwAuthenticate).decode('utf-8') if self._data.wwwAuthenticate != FFI_BROKER.NULL else None

    @www_authenticate.setter
    def www_authenticate(self, value: str) -> None:
        if value is None:
            self._data.wwwAuthenticate = FFI_BROKER.NULL
            return

        self._www_authenticate = value
        self._www_authenticate_utf8 = self._www_authenticate.encode('utf-8')
        self._www_authenticate_cffi = FFI_BROKER.new('char[]', self._www_authenticate_utf8)
        self._data.wwwAuthenticate = self._www_authenticate_cffi

    @property
    def authorization_header(self) -> str:
        return FFI_BROKER.string(self._data.authorizationHeader).decode('utf-8') if self._data.authorizationHeader != FFI_BROKER.NULL else None

    @authorization_header.setter
    def authorization_header(self, value: str) -> None:
        if value is None:
            self._data.authorizationHeader = FFI_BROKER.NULL
            return

        self._authorization_header = value
        self._authorization_header_utf8 = self._authorization_header.encode('utf-8')
        self._authorization_header_cffi = FFI_BROKER.new('char[]', self._authorization_header_utf8)
        self._data.authorizationHeader = self._authorization_header_cffi

    @property
    def binding_certificate(self):
        """
        Platform-specific certificate data (PCCERT_CONTEXT on Windows and nullptr on other platforms).
        Returns the raw pointer value.
        """
        return self._data.bindingCertificate if self._data.bindingCertificate != FFI_BROKER.NULL else None

    @binding_certificate.setter
    def binding_certificate(self, value) -> None:
        self._data.bindingCertificate = value

    @property
    def long_running_web_api_session_key(self) -> str:
        """Auto-generated long running web API session key, returned when 'AllocateForMe' was specified."""
        return FFI_BROKER.string(self._data.longRunningWebApiSessionKey).decode('utf-8') if self._data.longRunningWebApiSessionKey != FFI_BROKER.NULL else None

    @long_running_web_api_session_key.setter
    def long_running_web_api_session_key(self, value: str) -> None:
        if value is None:
            self._data.longRunningWebApiSessionKey = FFI_BROKER.NULL
            return

        self._long_running_web_api_session_key = value
        self._long_running_web_api_session_key_utf8 = self._long_running_web_api_session_key.encode('utf-8')
        self._long_running_web_api_session_key_cffi = FFI_BROKER.new('char[]', self._long_running_web_api_session_key_utf8)
        self._data.longRunningWebApiSessionKey = self._long_running_web_api_session_key_cffi

    @property
    def metadata(self) -> str:
        """
        Token-acquisition metadata as a JSON string (token source, cache level/refresh reason,
        region, durations, expiry/refresh times), or None when unavailable.

        For diagnostics/telemetry only: the content and format are not contractual and may
        change - do not parse it or take a dependency on it.
        """
        return FFI_BROKER.string(self._data.metadata).decode('utf-8') if self._data.metadata != FFI_BROKER.NULL else None

    @property
    def failure_details(self) -> str:
        """
        Token-acquisition failure diagnostics as a JSON string (error code, sub-error, HTTP status,
        claims challenge, correlation id), or None on success / when unavailable.

        For diagnostics/telemetry only: the content and format are not contractual and may
        change - do not parse it or take a dependency on it.
        """
        return FFI_BROKER.string(self._data.failureDetails).decode('utf-8') if self._data.failureDetails != FFI_BROKER.NULL else None

class MiseDownstreamApiOptionsOverrides:
    """
    Override structure for the MiseDownstreamApiInput and MiseDownstreamAuthorizationHeaderInput input structs.
    This structure can optionally be used to override config options.
    """

    def __init__(self, ffi_data = None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseDownstreamApiOptionsOverrides*")
        else:
            self._data = ffi_data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def scopes(self) -> list[str]:
        res = []
        for i in range(int(self._data.scopesCount)):
            res.append(str(self._data.scopes[i]))

        return res

    @scopes.setter
    def scopes(self, value) -> list[str]:
        pass

    @property
    def scopes_count(self) -> int:
        ""
        res = self._data.scopesCount
        return res

    @scopes_count.setter
    def scopes_count(self, value) -> int:
        self._data.scopesCount = value

    @property
    def tenant(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.tenant).decode('utf-8') if self._data.tenant != FFI_BROKER.NULL else None
        return res

    @tenant.setter
    def tenant(self, value) -> str:
        ""
        if value is None:
            self._data.tenant = FFI_BROKER.NULL
            return

        self._tenant = value
        self._tenant_utf8 = self._tenant.encode('utf-8')
        self._tenant_cffi = FFI_BROKER.new('char[]', self._tenant_utf8)
        self._data.tenant = self._tenant_cffi

    @property
    def claims_json(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.claimsJson).decode('utf-8') if self._data.claimsJson != FFI_BROKER.NULL else None
        return res

    @claims_json.setter
    def claims_json(self, value) -> str:
        ""
        if value is None:
            self._data.claimsJson = FFI_BROKER.NULL
            return

        self._claims_json = value
        self._claims_json_utf8 = self._claims_json.encode('utf-8')
        self._claims_json_cffi = FFI_BROKER.new('char[]', self._claims_json_utf8)
        self._data.claimsJson = self._claims_json_cffi

    @property
    def managed_identity_client_id(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.managedIdentityClientId).decode('utf-8') if self._data.managedIdentityClientId != FFI_BROKER.NULL else None
        return res

    @managed_identity_client_id.setter
    def managed_identity_client_id(self, value) -> str:
        ""
        if value is None:
            self._data.managedIdentityClientId = FFI_BROKER.NULL
            return

        self._managed_identity_client_id = value
        self._managed_identity_client_id_utf8 = self._managed_identity_client_id.encode('utf-8')
        self._managed_identity_client_id_cffi = FFI_BROKER.new('char[]', self._managed_identity_client_id_utf8)
        self._data.managedIdentityClientId = self._managed_identity_client_id_cffi

    @property
    def managed_identity_base64_encoded_certificate(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.managedIdentityBase64encodedCertificate).decode('utf-8') if self._data.managedIdentityBase64encodedCertificate != FFI_BROKER.NULL else None
        return res

    @managed_identity_base64_encoded_certificate.setter
    def managed_identity_base64_encoded_certificate(self, value) -> str:
        ""
        if value is None:
            self._data.managedIdentityBase64encodedCertificate = FFI_BROKER.NULL
            return

        self._managed_identity_base64_encoded_certificate = value
        self._managed_identity_base64_encoded_certificate_utf8 = self._managed_identity_base64_encoded_certificate.encode('utf-8')
        self._managed_identity_base64_encoded_certificate_cffi = FFI_BROKER.new('char[]', self._managed_identity_base64_encoded_certificate_utf8)
        self._data.managedIdentityBase64encodedCertificate = self._managed_identity_base64_encoded_certificate_cffi

    @property
    def azure_region(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.azureRegion).decode('utf-8') if self._data.azureRegion != FFI_BROKER.NULL else None
        return res

    @azure_region.setter
    def azure_region(self, value) -> str:
        ""
        if value is None:
            self._data.azureRegion = FFI_BROKER.NULL
            return

        self._azure_region = value
        self._azure_region_utf8 = self._azure_region.encode('utf-8')
        self._azure_region_cffi = FFI_BROKER.new('char[]', self._azure_region_utf8)
        self._data.azureRegion = self._azure_region_cffi

    @property
    def signed_client_assertion(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.signedClientAssertion).decode('utf-8') if self._data.signedClientAssertion != FFI_BROKER.NULL else None
        return res

    @signed_client_assertion.setter
    def signed_client_assertion(self, value) -> str:
        ""
        if value is None:
            self._data.signedClientAssertion = FFI_BROKER.NULL
            return

        self._signed_client_assertion = value
        self._signed_client_assertion_utf8 = self._signed_client_assertion.encode('utf-8')
        self._signed_client_assertion_cffi = FFI_BROKER.new('char[]', self._signed_client_assertion_utf8)
        self._data.signedClientAssertion = self._signed_client_assertion_cffi

    @property
    def fmi_path(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.fmiPath).decode('utf-8') if self._data.fmiPath != FFI_BROKER.NULL else None
        return res

    @fmi_path.setter
    def fmi_path(self, value) -> str:
        ""
        if value is None:
            self._data.fmiPath = FFI_BROKER.NULL
            return

        self._fmi_path = value
        self._fmi_path_utf8 = self._fmi_path.encode('utf-8')
        self._fmi_path_cffi = FFI_BROKER.new('char[]', self._fmi_path_utf8)
        self._data.fmiPath = self._fmi_path_cffi

    @property
    def force_refresh(self) -> bool:
        ""
        return self._data.forceRefresh != 0

    @force_refresh.setter
    def force_refresh(self, value: bool) -> None:
        ""
        self._data.forceRefresh = 1 if value else 0

    @property
    def authorization_details(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.authorizationDetails).decode('utf-8') if self._data.authorizationDetails != FFI_BROKER.NULL else None
        return res

    @authorization_details.setter
    def authorization_details(self, value: str) -> None:
        ""
        if value is None:
            self._data.authorizationDetails = FFI_BROKER.NULL
            return

        self._authorization_details = value
        self._authorization_details_utf8 = self._authorization_details.encode('utf-8')
        self._authorization_details_cffi = FFI_BROKER.new('char[]', self._authorization_details_utf8)
        self._data.authorizationDetails = self._authorization_details_cffi

    @property
    def pdp_configuration_section(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.pdpConfigurationSection).decode('utf-8') if self._data.pdpConfigurationSection != FFI_BROKER.NULL else None
        return res

    @pdp_configuration_section.setter
    def pdp_configuration_section(self, value: str) -> None:
        ""
        if value is None:
            self._data.pdpConfigurationSection = FFI_BROKER.NULL
            return

        self._pdp_configuration_section = value
        self._pdp_configuration_section_utf8 = self._pdp_configuration_section.encode('utf-8')
        self._pdp_configuration_section_cffi = FFI_BROKER.new('char[]', self._pdp_configuration_section_utf8)
        self._data.pdpConfigurationSection = self._pdp_configuration_section_cffi

    @property
    def constraint_tenant(self) -> str:
        """Enables to override the constraint tenant ID (c.tid) in CDT tokens. If not set, uses 'tenant' value for both t.tid (token tenant ID) and c.tid."""
        res = FFI_BROKER.string(self._data.constraintTenant).decode('utf-8') if self._data.constraintTenant != FFI_BROKER.NULL else None
        return res

    @constraint_tenant.setter
    def constraint_tenant(self, value: str) -> None:
        """
       Enables to override the constraint tenant ID (c.tid) in CDT tokens.
        If not set, uses 'tenant' value for both t.tid (token tenant ID) and c.tid.
        """
        if value is None:
            self._data.constraintTenant = FFI_BROKER.NULL
            return

        self._constraint_tenant = value
        self._constraint_tenant_utf8 = self._constraint_tenant.encode('utf-8')
        self._constraint_tenant_cffi = FFI_BROKER.new('char[]', self._constraint_tenant_utf8)
        self._data.constraintTenant = self._constraint_tenant_cffi

    @property
    def long_running_web_api_session_key(self) -> str:
        """Key for long-running web API session. Use 'AllocateForMe' to have MISE auto-generate a session key."""
        res = FFI_BROKER.string(self._data.longRunningWebApiSessionKey).decode('utf-8') if self._data.longRunningWebApiSessionKey != FFI_BROKER.NULL else None
        return res

    @long_running_web_api_session_key.setter
    def long_running_web_api_session_key(self, value: str) -> None:
        """Key for long-running web API session. Use 'AllocateForMe' to have MISE auto-generate a session key."""
        if value is None:
            self._data.longRunningWebApiSessionKey = FFI_BROKER.NULL
            return

        self._long_running_web_api_session_key = value
        self._long_running_web_api_session_key_utf8 = self._long_running_web_api_session_key.encode('utf-8')
        self._long_running_web_api_session_key_cffi = FFI_BROKER.new('char[]', self._long_running_web_api_session_key_utf8)
        self._data.longRunningWebApiSessionKey = self._long_running_web_api_session_key_cffi

    @property
    def relative_path(self) -> str:
        """URL path to be appended for the downstream API call."""
        return FFI_BROKER.string(self._data.relativePath).decode('utf-8') if self._data.relativePath != FFI_BROKER.NULL else None

    @relative_path.setter
    def relative_path(self, value: str) -> None:
        if value is None:
            self._data.relativePath = FFI_BROKER.NULL
            return

        self._relative_path = value
        self._relative_path_utf8 = self._relative_path.encode('utf-8')
        self._relative_path_cffi = FFI_BROKER.new('char[]', self._relative_path_utf8)
        self._data.relativePath = self._relative_path_cffi

    @property
    def constraints(self) -> list[str]:
        """Constraints as JSON objects."""
        if self._data.constraints == FFI_BROKER.NULL or self._data.constraintsCount == 0:
            return []
        return [FFI_BROKER.string(self._data.constraints[i]).decode('utf-8') for i in range(self._data.constraintsCount)]

    @constraints.setter
    def constraints(self, value: list[str]) -> None:
        if value is None or len(value) == 0:
            self._data.constraints = FFI_BROKER.NULL
            self._data.constraintsCount = 0
            return

        self._constraints_utf8 = [s.encode('utf-8') for s in value]
        self._constraints_cffi = [FFI_BROKER.new('char[]', s) for s in self._constraints_utf8]
        self._constraints_array = FFI_BROKER.new('char*[]', self._constraints_cffi)
        self._data.constraints = self._constraints_array
        self._data.constraintsCount = len(value)

    @property
    def constraints_count(self) -> int:
        return self._data.constraintsCount

    @constraints_count.setter
    def constraints_count(self, value: int) -> None:
        self._data.constraintsCount = value

    @property
    def attribute_tokens(self) -> list[str]:
        """Attribute tokens to be used when acquiring AuthN tokens."""
        if self._data.attributeTokens == FFI_BROKER.NULL or self._data.attributeTokensCount == 0:
            return []
        return [FFI_BROKER.string(self._data.attributeTokens[i]).decode('utf-8') for i in range(self._data.attributeTokensCount)]

    @attribute_tokens.setter
    def attribute_tokens(self, value: list[str]) -> None:
        if value is None or len(value) == 0:
            self._data.attributeTokens = FFI_BROKER.NULL
            self._data.attributeTokensCount = 0
            return

        self._attribute_tokens_utf8 = [s.encode('utf-8') for s in value]
        self._attribute_tokens_cffi = [FFI_BROKER.new('char[]', s) for s in self._attribute_tokens_utf8]
        self._attribute_tokens_array = FFI_BROKER.new('char*[]', self._attribute_tokens_cffi)
        self._data.attributeTokens = self._attribute_tokens_array
        self._data.attributeTokensCount = len(value)

    @property
    def attribute_tokens_count(self) -> int:
        return self._data.attributeTokensCount

    @attribute_tokens_count.setter
    def attribute_tokens_count(self, value: int) -> None:
        self._data.attributeTokensCount = value

    @property
    def client_assertion_claims(self) -> str:
        """
        Optional client claims to add to the client assertion when using managedIdentityBase64encodedCertificate.
        Claims should be a JSON dictionary serialized as a string. Claim names must be unique.
        """
        return FFI_BROKER.string(self._data.clientAssertionClaims).decode('utf-8') if self._data.clientAssertionClaims != FFI_BROKER.NULL else None

    @client_assertion_claims.setter
    def client_assertion_claims(self, value: str) -> None:
        if value is None:
            self._data.clientAssertionClaims = FFI_BROKER.NULL
            return

        self._client_assertion_claims = value
        self._client_assertion_claims_utf8 = self._client_assertion_claims.encode('utf-8')
        self._client_assertion_claims_cffi = FFI_BROKER.new('char[]', self._client_assertion_claims_utf8)
        self._data.clientAssertionClaims = self._client_assertion_claims_cffi

class MiseDownstreamAuthorizationHeaderInput:
    """

    """

    def __init__(self, ffi_data = None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseDownstreamAuthorizationHeaderInput*")
        else:
            self._data = ffi_data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def correlation_id(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.correlationId).decode('utf-8') if self._data.correlationId != FFI_BROKER.NULL else None
        return res

    @correlation_id.setter
    def correlation_id(self, value) -> str:
        if value is None:
            self._data.correlationId = FFI_BROKER.NULL
            return

        self._correlation_id = value
        self._correlation_id_utf8 = self._correlation_id.encode('utf-8')
        self._correlation_id_cffi = FFI_BROKER.new('char[]', self._correlation_id_utf8)
        self._data.correlationId = self._correlation_id_cffi

    @property
    def overrides(self) -> MiseDownstreamApiOptionsOverrides:
        ""
        res = self._data.overrides
        return res

    @overrides.setter
    def overrides(self, value) -> MiseDownstreamApiOptionsOverrides:
        pass

class MiseDownstreamApiInput:
    """

    """

    def __init__(self, ffi_data = None):
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseDownstreamApiInput*")
        else:
            self._data = ffi_data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def correlation_id(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.correlationId).decode('utf-8') if self._data.correlationId != FFI_BROKER.NULL else None
        return res

    @correlation_id.setter
    def correlation_id(self, value) -> str:
        ""
        if value is None:
            self._data.correlationId = FFI_BROKER.NULL
            return

        self._correlation_id = value
        self._correlation_id_utf8 = self._correlation_id.encode('utf-8')
        self._correlation_id_cffi = FFI_BROKER.new('char[]', self._correlation_id_utf8)
        self._data.correlationId = self._correlation_id_cffi

    @property
    def content_type(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.contentType).decode('utf-8') if self._data.contentType != FFI_BROKER.NULL else None
        return res

    @content_type.setter
    def content_type(self, value) -> str:
        ""
        if value is None:
            self._data.contentType = FFI_BROKER.NULL
            return

        self._content_type = value
        self._content_type_utf8 = self._content_type.encode('utf-8')
        self._content_type_cffi = FFI_BROKER.new('char[]', self._content_type_utf8)
        self._data.contentType = self._content_type_cffi

    @property
    def input_body(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.inputBody).decode('utf-8') if self._data.inputBody != FFI_BROKER.NULL else None
        return res

    @input_body.setter
    def input_body(self, value) -> str:
        ""
        if value is None:
            self._data.inputBody = FFI_BROKER.NULL
            return

        self._input_body = value
        self._input_body_utf8 = self._input_body.encode('utf-8')
        self._input_body_cffi = FFI_BROKER.new('char[]', self._input_body_utf8)
        self._data.inputBody = self._input_body_cffi

    @property
    def accept_header(self) -> str:
        ""
        res = FFI_BROKER.string(self._data.acceptHeader).decode('utf-8') if self._data.acceptHeader != FFI_BROKER.NULL else None
        return res

    @accept_header.setter
    def accept_header(self, value) -> str:
        ""
        if value is None:
            self._data.acceptHeader = FFI_BROKER.NULL
            return

        self._accept_header = value
        self._accept_header_utf8 = self._accept_header.encode('utf-8')
        self._accept_header_cffi = FFI_BROKER.new('char[]', self._accept_header_utf8)
        self._data.acceptHeader = self._accept_header_cffi

    @property
    def overrides(self) -> MiseDownstreamApiOptionsOverrides:
        ""
        res = self._data.overrides
        return res

    @overrides.setter
    def overrides(self, value) -> MiseDownstreamApiOptionsOverrides:
        pass

class MiseDownstreamApiResult:
    """
    Container class for downstream API results.
    """

    def __init__(self, ffi_data=None):
        # Only native (MISE-allocated) memory may be released via MiseFree*. Memory that
        # cffi allocates for empty-constructed wrappers is owned by cffi and must not be
        # passed to MiseFree* (cross-allocator/double free) — cffi reclaims it on GC.
        self._owns_native = ffi_data is not None
        if ffi_data is None:
            self._data = FFI_BROKER.new("MiseDownstreamApiResult*")
        else:
            self._data = ffi_data

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self._owns_native and self._data is not None:
            MISE_LIBRARY.MiseFreeDownstreamApiResult(self._data)
            self._data = None

    def __del__(self):
        # During interpreter shutdown module globals may already be torn down to None;
        # capture a local ref and guard to avoid noisy "Exception ignored in __del__".
        lib = MISE_LIBRARY
        if lib is not None and getattr(self, '_owns_native', False) and self._data is not None:
            lib.MiseFreeDownstreamApiResult(self._data)
            self._data = None

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def http_response_status_code(self) -> int:
        return self._data.httpResponseStatusCode

    @http_response_status_code.setter
    def http_response_status_code(self, value: int) -> None:
        self._data.httpResponseStatusCode = value

    @property
    def correlation_id(self) -> str:
        return FFI_BROKER.string(self._data.correlationId).decode('utf-8') if self._data.correlationId != FFI_BROKER.NULL else None

    @correlation_id.setter
    def correlation_id(self, value: str) -> None:
        if value is None:
            self._data.correlationId = FFI_BROKER.NULL
            return

        self._correlation_id = value
        self._correlation_id_utf8 = self._correlation_id.encode('utf-8')
        self._correlation_id_cffi = FFI_BROKER.new('char[]', self._correlation_id_utf8)
        self._data.correlationId = self._correlation_id_cffi

    @property
    def error_description(self) -> str:
        return FFI_BROKER.string(self._data.errorDescription).decode('utf-8') if self._data.errorDescription != FFI_BROKER.NULL else None

    @error_description.setter
    def error_description(self, value: str) -> None:
        if value is None:
            self._data.errorDescription = FFI_BROKER.NULL
            return

        self._error_description = value
        self._error_description_utf8 = self._error_description.encode('utf-8')
        self._error_description_cffi = FFI_BROKER.new('char[]', self._error_description_utf8)
        self._data.errorDescription = self._error_description_cffi

    @property
    def www_authenticate(self) -> str:
        return FFI_BROKER.string(self._data.wwwAuthenticate).decode('utf-8') if self._data.wwwAuthenticate != FFI_BROKER.NULL else None

    @www_authenticate.setter
    def www_authenticate(self, value: str) -> None:
        if value is None:
            self._data.wwwAuthenticate = FFI_BROKER.NULL
            return

        self._www_authenticate = value
        self._www_authenticate_utf8 = self._www_authenticate.encode('utf-8')
        self._www_authenticate_cffi = FFI_BROKER.new('char[]', self._www_authenticate_utf8)
        self._data.wwwAuthenticate = self._www_authenticate_cffi

    @property
    def downstream_api_result(self) -> str:
        return FFI_BROKER.string(self._data.downstreamApiResult).decode('utf-8') if self._data.downstreamApiResult != FFI_BROKER.NULL else None

    @downstream_api_result.setter
    def downstream_api_result(self, value: str) -> None:
        if value is None:
            self._data.downstreamApiResult = FFI_BROKER.NULL
            return

        self._downstream_api_result = value
        self._downstream_api_result_utf8 = self._downstream_api_result.encode('utf-8')
        self._downstream_api_result_cffi = FFI_BROKER.new('char[]', self._downstream_api_result_utf8)
        self._data.downstreamApiResult = self._downstream_api_result_cffi

class Mise:
    """
    Core class that provides access to the MISE Native library functionality.
    """

    def __init__(self):
        """
        Initialize MISE by loading the native MISE library.

        Raises:
            ValueError: If the FFI section extraction fails.
        """
        path_to_dll = self.get_mise_binary_path()

        global FFI_BROKER
        global MISE_LIBRARY

        # Create the FFI instance, load the native library and parse the header exactly
        # once per process, then reuse it for every Mise() instance. Re-running cdef() on
        # each construction is not only wasteful (it re-parses the ~65KB header), it is
        # unsafe: cdef() holds the cffi ffi._lock while pycparser parses, and a garbage
        # collection triggered mid-parse can run a finalizer (e.g. MiseValidationResult
        # .__del__) that calls back into the library and tries to re-acquire that same
        # lock on the same thread, deadlocking the interpreter. Building the FFI once and
        # sharing it also keeps every cffi object bound to a single FFI instance, avoiding
        # "mixing up different ffi instances" errors when older objects are finalized.
        if MISE_LIBRARY is None:
            with _FFI_INIT_LOCK:
                if MISE_LIBRARY is None:
                    ffi = FFI()

                    # On Linux, pin the native library so that dlclose() (called by cffi
                    # during Python GC) decrements the ref-count but never unmaps the
                    # code pages. Without this, the dynamic linker can unmap libmise.so
                    # while NativeAOT runtime threads are still running, causing a
                    # segfault on process exit.
                    # See: https://github.com/dotnet/runtime/issues/103028
                    if sys.platform == "linux":
                        _RTLD_NODELETE = 0x01000
                        ctypes.CDLL(path_to_dll, mode=os.RTLD_LAZY | _RTLD_NODELETE)

                    library = ffi.dlopen(path_to_dll)
                    section = self.extract_section()

                    if not section:
                        raise ValueError("Failed to extract FFI section from the header file.")

                    ffi.cdef(section)

                    # Publish the fully-initialized instances only after cdef() succeeds so
                    # other threads never observe a partially-configured FFI_BROKER.
                    FFI_BROKER = ffi
                    MISE_LIBRARY = library

        # Storage for native callback handles to prevent garbage collection
        self._log_message_callback = None
        self._prefetch_callback = None
        self._validate_context_callback = None
        self._l2_cache_get_data_callback = None
        self._l2_cache_free_get_data_result_callback = None
        self._l2_cache_get_data_async_callback = None
        self._l2_cache_free_get_data_async_result_callback = None
        self._l2_cache_set_data_callback = None
        self._l2_cache_free_set_data_result_callback = None
        self._l2_cache_set_data_async_callback = None
        self._l2_cache_free_set_data_async_result_callback = None
        self._rbac_filter_callback = None
        self._validate_azure_authz_callback = None

        # Set of live async callback handles — prevents GC while native code holds a pointer.
        # Each callback removes itself from the set when it fires, allowing GC afterward.
        # Python's set provides O(1) add/discard. The set size is bounded by the number
        # of in-flight async operations, not total throughput. CPython's GIL serializes
        # set mutations, so concurrent callbacks do not cause data races.
        self._live_async_callbacks = set()

    def get_bin_folder_path(self):
        """
        Retrieve the path to the binary folder relative to the package directory.

        This method constructs and returns the path to the `lib` directory inside
        the package directory. This folder contains the MISE Native binary files.

        Returns:
            str: The absolute path to the binary folder as a string.
        """
        return str(resources.files('mise').joinpath('lib'))

    def get_mise_header_path(self):
        """
        Get the path to the MISE header file (`mise.h`) in the binary folder.

        This method constructs the path to the `mise.h` header file, which is expected
        to be located in the binary folder. It checks if the file exists at the constructed
        path and returns the absolute path if it does.

        Returns:
            str: The absolute path to the `mise.h` header file.

        Raises:
            FileNotFoundError: If the `mise.h` file is not found in the binary folder.
        """
        bin_folder_path = self.get_bin_folder_path()
        file_path = os.path.join(bin_folder_path, 'mise.h')
        if os.path.exists(file_path):
            return file_path
        else:
            raise FileNotFoundError(f"The header {file_path!r} was not found. Please ensure that it's included in the 'bin' directory.")

    def get_mise_binary_path(self):
        """
        Determine the path to the MISE binary file based on the operating system and architecture.

        This method constructs the path to the MISE binary file (`mise.dll` or `libmise.so`)
        based on the detected operating system and architecture. It checks if the constructed
        file path exists and returns it if found. The method supports different binary file
        names and locations for various platforms.

        Returns:
            str: The absolute path to the MISE binary file if it is found.

        Raises:
            ValueError: If the operating system or architecture is not supported.
            FileNotFoundError: If the constructed file path does not exist.
        """

        operating_system, arch = self.get_system_info()

        bin_folder_path = self.get_bin_folder_path()

        if operating_system == "windows" and arch == "x64":
            file_path = os.path.join(bin_folder_path, 'win-x64', 'mise.dll')
        elif operating_system == "windows" and arch == "arm64":
            file_path = os.path.join(bin_folder_path, 'win-arm64', 'mise.dll')
        elif operating_system == "linux" and arch == "x64":
            file_path = os.path.join(bin_folder_path, 'linux-x64', 'libmise.so')
        else:
            raise ValueError(f"Platform {operating_system!r} with architecture {arch!r} is not supported.")

        if os.path.exists(file_path):
            return file_path
        else:
            raise FileNotFoundError(f"The binary {file_path!r} was not found. Please ensure that it's included in the 'bin' directory.")

    def extract_section(self):
        """
        Extract and clean a specific section from the MISE header file.

        This method reads the MISE header file and extracts lines between the markers
        `// FFI BEGIN` and `// FFI END`. It then performs string replacements to remove
        specific macros used in the header file.

        Returns:
            str: The cleaned section extracted from the header file. If no section is
                found or if the file is empty, `None` is returned.

        Raises:
            FileNotFoundError: If the header file cannot be found or opened.
        """
        start_marker = "// FFI BEGIN"
        end_marker = "// FFI END"

        header_path = self.get_mise_header_path()

        result_lines = []
        inside_section = False

        with open(header_path, 'r', encoding='utf-8') as file:
            for line in file:
                if line.startswith(start_marker):
                    inside_section = True
                    continue

                if line.startswith(end_marker):
                    inside_section = False
                    break

                if inside_section:
                    result_lines.append(line)

        if result_lines:
            result_string = ''.join(result_lines)

            replacements = {
                "MISE_EXTERN_C": "",
                "MISE_API": "",
                "MISE_CALLTYPE": ""
            }

            for old, new in replacements.items():
                result_string = result_string.replace(old, new)

            return result_string
        return None

    def configure(
        self,
        configuration_json : str,
        configuration_section: str,
    ) -> MiseControlResult:
        """
        Initializes the MISE Native library, making it ready to call flow functions.

        This method interacts with the native MISE library to apply configuration settings
        based on the provided JSON configuration string and section name. It calls the
        `MiseConfigure` function from the MISE native library.

        Args:
            configuration_json (str): The MISE Native JSON configuration. See `example in the MISE repo <https://identitydivision.visualstudio.com/DevEx/_git/MISE?path=/docs/container/Configuration.md&_a=preview>`_.
            configuration_section (str): Optional: section name in the configuration JSON, 'AzureAd' if NULL.

        Returns:
            MiseControlResult: An instance of `MiseControlResult` containing the result of the configuration.

        Raises:
            ValueError: If the `MiseConfigure` function returns an invalid result or if the configuration fails.

        Example:
            >>> mise_client = mise.Mise()
            >>> result = mise_client.configure(configuration_json, "AzureAD")
        """
        res = MISE_LIBRARY.MiseConfigure(
            configuration_json.encode('utf-8'),
            configuration_section.encode('utf-8') if configuration_section is not None else FFI_BROKER.NULL
        )

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def configure_with_app_switches(
        self,
        configuration_json: str,
        configuration_section: str,
        app_switches: MiseAppSwitchesInput,
    ) -> MiseControlResult:
        """
        Initializes the MISE Native library with application switches, making it ready to call flow functions.

        This method interacts with the native MISE library to apply configuration settings
        based on the provided JSON configuration string, section name, and application switches.

        Args:
            configuration_json (str): The MISE Native JSON configuration.
            configuration_section (str): Optional: section name in the configuration JSON, 'AzureAd' if NULL.
            app_switches (MiseAppSwitchesInput): Application switches input structure.

        Returns:
            MiseControlResult: An instance of `MiseControlResult` containing the result of the configuration.

        Example:
            >>> mise_client = mise.Mise()
            >>> switches_input = mise.MiseAppSwitchesInput()
            >>> switches_input.switches = ["MISE_SWITCH_REGISTER_CLAIMS_ONLY_AUTHZ"]
            >>> result = mise_client.configure_with_app_switches(configuration_json, "AzureAD", switches_input)
        """
        res = MISE_LIBRARY.MiseConfigureWithAppSwitches(
            configuration_json.encode('utf-8'),
            configuration_section.encode('utf-8') if configuration_section is not None else FFI_BROKER.NULL,
            app_switches.data
        )

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def assign_log_message_callback(
        self,
        callback,
        native_context=None,
    ) -> MiseControlResult:
        """
        Assigns a user logging callback function to MISE.

        Must be called before configure(). Expected to be called only once.

        Args:
            callback: A callable that receives (MiseLogMessageCallbackContext, native_context).
            native_context: Optional user-defined context pointer passed through to the callback.

        Returns:
            MiseControlResult: Result of the operation.

        Example:
            >>> def on_log(ctx, _):
            ...     print(f"[{ctx.level}] {ctx.message}")
            >>> mise_client.assign_log_message_callback(on_log)
        """
        @FFI_BROKER.callback("void(MiseLogMessageCallbackContext*, void*)")
        def _cb(raw_ctx, raw_native_ctx):
            callback(MiseLogMessageCallbackContext(raw_ctx), raw_native_ctx)

        self._log_message_callback = _cb
        context_ptr = FFI_BROKER.NULL if native_context is None else FFI_BROKER.new_handle(native_context)

        res = MISE_LIBRARY.MiseAssignLogMessageCallback(_cb, context_ptr)
        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def unassign_log_message_callback(self) -> MiseControlResult:
        """
        Unassigns the logging message callback function.

        Returns:
            MiseControlResult: Result of the operation.
        """
        self._log_message_callback = None
        res = MISE_LIBRARY.MiseUnassignLogMessageCallback()
        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def prefetch_openid_configuration_async(
        self,
        timeout_in_seconds: int,
        completion_callback,
        native_context=None,
    ) -> None:
        """
        Warms up OIDC metadata caches (local and L2 cache if set).

        This function warms up OIDC metadata caches. The completion callback will be called
        when the operation is completed.

        Args:
            timeout_in_seconds (int): Timeout for the prefetch operation in seconds.
            completion_callback: Callback function of type MiseCompletionCallbackFunc.
            native_context: Optional: A user-defined pointer representing state needed within the callback.

        Example:
            >>> def on_completion(result, context):
            >>>     print(f"Prefetch completed with error code: {result.error_code}")
            >>> mise_client.prefetch_openid_configuration_async(30, on_completion)
        """
        callback_handle = FFI_BROKER.callback("void(MiseControlResult*, void*)", completion_callback)
        self._prefetch_callback = callback_handle
        context_ptr = FFI_BROKER.NULL if native_context is None else FFI_BROKER.new_handle(native_context)

        MISE_LIBRARY.MisePrefetchOpenIdConfigurationAsync(
            timeout_in_seconds,
            callback_handle,
            context_ptr
        )

    def validate(
        self,
        validation_input : MiseValidationInput,
    ) -> MiseValidationResult:
        """
        Validates authentication using a provided input structure. This function offers a validation functionality with extracted commonly used fields.

        This method sends the input data to the MISE library for validation. It calls the
        `MiseValidate` function from the MISE native library and processes the result to return
        a validation outcome.

        Args:
            input (MiseValidationInput): The input headers structured as `MiseValidationInput`.

        Returns:
            MiseValidationResult: An instance of `MiseValidationResult` representing the result of the validation.

        Raises:
            ValueError: If the validation result is invalid or if there is an error in the interaction with the MISE native library.

        Example:
            >>> validation_input = mise.MiseValidationInput()
            >>> validation_input.authorization_header = AUTHORIZATION_HEADER_WITH_TOKEN
            >>> validation_input.original_uri_header = ORIGINAL_URI
            >>> validation_input.original_method_header = ORIGINAL_METHOD
            >>> new_vr = mise_client.validate(validation_input)
        """
        res = MISE_LIBRARY.MiseValidate(
           validation_input.data,
        )

        return MiseValidationResult(FFI_BROKER.cast('MiseValidationResult*', res))

    def validate_with_context(
        self,
        validation_input: MiseValidationInput,
        callback,
        caller_context=None,
    ) -> MiseValidationResult:
        """
        Validates authentication using a provided input structure with a context callback.

        This function offers validation functionality with the ability to customize the request
        through a callback function.

        Args:
            validation_input (MiseValidationInput): The input headers structured as `MiseValidationInput`.
            callback: The callback function that will receive the request context.
            caller_context: Optional: An opaque object that will be returned as the second parameter in the callback.

        Returns:
            MiseValidationResult: An instance of `MiseValidationResult` representing the result of the validation.

        Example:
            >>> def context_callback(request_object, caller_context):
            >>>     # Customize request here
            >>>     pass
            >>> validation_input = mise.MiseValidationInput()
            >>> result = mise_client.validate_with_context(validation_input, context_callback)
        """
        callback_handle = FFI_BROKER.callback("void(void*, void*)", callback)
        self._validate_context_callback = callback_handle
        context_ptr = FFI_BROKER.NULL if caller_context is None else FFI_BROKER.new_handle(caller_context)

        res = MISE_LIBRARY.MiseValidateWithContext(
            validation_input.data,
            callback_handle,
            context_ptr
        )

        return MiseValidationResult(FFI_BROKER.cast('MiseValidationResult*', res))

    def validate_with_azure_authorization_module(
        self,
        validation_input: MiseValidationInput,
        callback,
        caller_context=None,
    ) -> MiseValidationResult:
        """
        Validates authentication using Azure Authorization module with a context callback.

        This function offers validation functionality with Azure Authorization module integration.

        Args:
            validation_input (MiseValidationInput): The input headers structured as `MiseValidationInput`.
            callback: The callback function that will receive the request context.
            caller_context: Optional: An opaque object that will be returned as the second parameter in the callback.

        Returns:
            MiseValidationResult: An instance of `MiseValidationResult` representing the result of the validation.

        Example:
            >>> def context_callback(request_object, caller_context):
            >>>     # Set authorization payloads here
            >>>     pass
            >>> validation_input = mise.MiseValidationInput()
            >>> result = mise_client.validate_with_azure_authorization_module(validation_input, context_callback)
        """
        callback_handle = FFI_BROKER.callback("void(void*, void*)", callback)
        self._validate_azure_authz_callback = callback_handle
        context_ptr = FFI_BROKER.NULL if caller_context is None else FFI_BROKER.new_handle(caller_context)

        res = MISE_LIBRARY.MiseValidateWithAzureAuthorizationModule(
            validation_input.data,
            callback_handle,
            context_ptr
        )

        return MiseValidationResult(FFI_BROKER.cast('MiseValidationResult*', res))

    def set_claims_policies(
        self,
        request_object,
        policies: list[str],
    ) -> MiseControlResult:
        """
        Sets the claims-based policies for the current request.

        Args:
            request_object: Opaque pointer representing the current request object from the callback.
            policies (list[str]): An array representing policies.

        Returns:
            MiseControlResult: Result structure with the outcome.

        Example:
            >>> def context_callback(request_object, caller_context):
            >>>     policies = ["policy1", "policy2"]
            >>>     result = mise_client.set_claims_policies(request_object, policies)
        """
        policies_utf8 = [p.encode('utf-8') for p in policies]
        policies_cffi = [FFI_BROKER.new('char[]', p) for p in policies_utf8]
        policies_array = FFI_BROKER.new('char*[]', policies_cffi)

        res = MISE_LIBRARY.MiseSetClaimsPolicies(
            request_object,
            policies_array,
            len(policies)
        )

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def set_azure_authorization_request_payload(
        self,
        request_object,
        authorization_request: str,
    ) -> MiseControlResult:
        """
        Sets the authorization request payload on the MISE context.

        Args:
            request_object: Opaque pointer representing the current request object from the callback.
            authorization_request (str): The authorization request payload as a string.

        Returns:
            MiseControlResult: Result structure with the outcome.

        Example:
            >>> def context_callback(request_object, caller_context):
            >>>     result = mise_client.set_azure_authorization_request_payload(
            >>>         request_object,
            >>>         '{"action": "read"}'
            >>>     )
        """
        res = MISE_LIBRARY.MiseSetAzureAuthorizationRequestPayload(
            request_object,
            authorization_request.encode('utf-8')
        )

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def set_azure_authorization_data_fetch_payload(
        self,
        request_object,
        data_fetch_request: str,
    ) -> MiseControlResult:
        """
        Sets the data fetch request payload on the MISE context.

        Args:
            request_object: Opaque pointer representing the current request object from the callback.
            data_fetch_request (str): The data fetch request payload as a string.

        Returns:
            MiseControlResult: Result structure with the outcome.

        Example:
            >>> def context_callback(request_object, caller_context):
            >>>     result = mise_client.set_azure_authorization_data_fetch_payload(
            >>>         request_object,
            >>>         '{"scope": "/subscriptions/123"}'
            >>>     )
        """
        res = MISE_LIBRARY.MiseSetAzureAuthorizationDataFetchPayload(
            request_object,
            data_fetch_request.encode('utf-8')
        )

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def get_authorization_header(
        self,
        validation_result : MiseValidationResult,
        api_input : MiseDownstreamAuthorizationHeaderInput,
        downstream_api_name : str,
    ) -> MiseDownstreamAuthorizationHeaderResult:
        """
        This function is intended for consumers of the API to facilitate token acquisition for calling a downstream API.

        This method calls the `MiseGetAuthorizationHeader` function from the MISE native library
        to generate an authorization header for a downstream API.

        Args:
            validation_result (MiseValidationResult): A pointer to an instance of `MiseValidationResult` containing the result of previous validation.
            input (MiseDownstreamAuthorizationHeaderInput): A pointer to an instance of `MiseDownstreamAuthorizationHeaderInput` containing the input data required for authorization.
            downstream_api_name (str): The name or identifier of the downstream API being called as defined in the 'DownstreamApi' configuration section.

        Returns:
            MiseDownstreamAuthorizationHeaderResult: An instance of `MiseDownstreamAuthorizationHeaderResult` containing the authorization header for the downstream API.

        Raises:
            ValueError: If the authorization header result is invalid or if there is an error in interacting with the MISE library.

        Example:
            >>> api_vr = mise.MiseValidationResult()
            >>> api_input = mise.MiseDownstreamAuthorizationHeaderInput()
            >>> result = mise_client.get_authorization_header(
            >>>     validation_result=api_vr,
            >>>     input=api_input,
            >>>     downstream_api_name=DOWNSTREAM_API_NAME
            >>> )
            <MiseDownstreamAuthorizationHeaderResult object at 0x...>
        """
        res = MISE_LIBRARY.MiseGetAuthorizationHeader(
           validation_result.data,
           api_input.data,
           downstream_api_name.encode('utf-8'),
        )

        return MiseDownstreamAuthorizationHeaderResult(FFI_BROKER.cast('MiseDownstreamAuthorizationHeaderResult*', res))

    def get_authorization_header_unauthenticated(
        self,
        api_input : MiseDownstreamAuthorizationHeaderInput,
        downstream_api_name : str,
    ) -> MiseDownstreamAuthorizationHeaderResult:
        """
        Acquires an authentication token required to call a downstream API without requiring prior authentication.

        This function is intended for consumers of the API to facilitate token acquisition for calling a downstream API.
        The call is intended for endpoints that do not require authentication.

        This method calls the `MiseGetAuthorizationHeaderUnauthenticated` function from the MISE native library
        to generate an authorization header for a downstream API.

        Args:
            api_input (MiseDownstreamAuthorizationHeaderInput): A pointer to an instance of `MiseDownstreamAuthorizationHeaderInput` containing the input data required for authorization.
            downstream_api_name (str): The name or identifier of the downstream API being called as defined in the 'DownstreamApi' configuration section.

        Returns:
            MiseDownstreamAuthorizationHeaderResult: An instance of `MiseDownstreamAuthorizationHeaderResult` containing the authorization header for the downstream API.

        Raises:
            ValueError: If the authorization header result is invalid or if there is an error in interacting with the MISE library.

        Example:
            >>> api_input = mise.MiseDownstreamAuthorizationHeaderInput()
            >>> result = mise_client.get_authorization_header_unauthenticated(
            >>>     api_input=api_input,
            >>>     downstream_api_name=DOWNSTREAM_API_NAME
            >>> )
            <MiseDownstreamAuthorizationHeaderResult object at 0x...>
        """
        res = MISE_LIBRARY.MiseGetAuthorizationHeaderUnauthenticated(
           api_input.data,
           downstream_api_name.encode('utf-8'),
        )

        return MiseDownstreamAuthorizationHeaderResult(FFI_BROKER.cast('MiseDownstreamAuthorizationHeaderResult*', res))

    def call_downstream_api(
        self,
        validation_result : MiseValidationResult,
        api_input : MiseDownstreamApiInput,
        downstream_api_name : str,
    ) -> MiseDownstreamApiResult:
        """
        Invokes a downstream API that require authentication as provided in the input.

        This method interacts with the MISE native library to invoke a downstream API, calling the
        `MiseCallDownstreamApi` function.

        Args:
            validation_result (MiseValidationResult): Pointer to an instance of `MiseValidationResult` containing the result of a previous validation..
            input (MiseDownstreamApiInput): An instance of `MiseDownstreamApiInput` providing the necessary data for performing the downstream API request.
            downstream_api_name (str): The name or identifier of the downstream API being called as defined in the 'DownstreamApi' configuration section.

        Returns:
            MiseDownstreamApiResult: An instance of `MiseDownstreamApiResult` containing the result of the downstream API call.

        Raises:
            ValueError: If the provided `validation_result`, `input`, or `downstream_api_name` are invalid or if the API call fails.
        """
        res = MISE_LIBRARY.MiseCallDownstreamApi(
           validation_result.data,
           api_input.data,
           downstream_api_name.encode('utf-8'),
        )

        return MiseDownstreamApiResult(FFI_BROKER.cast('MiseDownstreamApiResult*', res))

    def call_downstream_api_unauthenticated(
        self,
        api_input : MiseDownstreamApiInput,
        downstream_api_name : str,
    ) -> MiseDownstreamApiResult:
        """
        Calls a downstream API without authentication using the provided input data and API name.

        This method interacts with the MISE native library to invoke a downstream API without requiring authentication
        by calling the `MiseCallDownstreamApiUnauthenticated` function.

        Args:
            input (MiseDownstreamApiInput): A pointer to an instance of `MiseDownstreamApiInput` providing the necessary data for authenticating the request.
            downstream_api_name (str): The name or identifier of the downstream API being called as defined in the 'DownstreamApi' configuration section.

        Returns:
            MiseDownstreamApiResult: An instance of `MiseDownstreamApiResult` containing the result of the downstream API call.

        Raises:
            ValueError: If the provided `input` or `downstream_api_name` are invalid or if the API call fails.
        """
        res = MISE_LIBRARY.MiseCallDownstreamApiUnauthenticated(
           api_input.data,
           downstream_api_name.encode('utf-8'),
        )

        return MiseDownstreamApiResult(FFI_BROKER.cast('MiseDownstreamApiResult*', res))

    # ---- Async API wrappers ----
    # Each async method returns a concurrent.futures.Future that will contain the result.
    # The native async API is fire-and-forget with a completion callback; these wrappers
    # bridge that to Python's Future for ergonomic use.

    def validate_async(
        self,
        validation_input: MiseValidationInput,
    ) -> Future:
        """
        Asynchronously validates authentication using a provided input structure.

        Returns a ``concurrent.futures.Future`` whose result is a ``MiseValidationResult``.
        The future is resolved when the native async callback fires.

        .. important::
            The caller **must** close the returned ``MiseValidationResult`` (via ``with`` or
            explicit ``__exit__``) to free native memory.

        Args:
            validation_input (MiseValidationInput): The input headers.

        Returns:
            Future[MiseValidationResult]: A future that will contain the validation result.
        """
        future = Future()

        @FFI_BROKER.callback("void(MiseValidationResult*, void*)")
        def _on_complete(result, ctx):
            try:
                wrapper = MiseValidationResult(FFI_BROKER.cast('MiseValidationResult*', result))
            except BaseException as e:
                # Construction failed before the wrapper took ownership; free the native
                # result here to avoid a leak.
                MISE_LIBRARY.MiseFreeValidationResult(result)
                _safe_set_exception(future, e)
                self._live_async_callbacks.discard(_on_complete)
                return
            try:
                future.set_result(wrapper)
            except BaseException as e:
                # Future already completed/cancelled. The wrapper now owns the native
                # pointer and frees it on GC — do not free it again here.
                _safe_set_exception(future, e)
            finally:
                self._live_async_callbacks.discard(_on_complete)

        # prevent GC of callback — safe for concurrent calls
        self._live_async_callbacks.add(_on_complete)

        MISE_LIBRARY.MiseValidateAsync(
            validation_input.data,
            _on_complete,
            FFI_BROKER.NULL,  # nativeContext is null — the Future closure captures all required state.
        )

        return future

    def validate_with_context_async(
        self,
        validation_input: MiseValidationInput,
        context_callback,
        caller_context=None,
    ) -> Future:
        """
        Asynchronously validates authentication with a context callback.

        The ``context_callback`` runs synchronously (to set claims/authorization payloads)
        before the async validation proceeds. The completion is delivered via the returned future.

        .. important::
            The caller **must** close the returned ``MiseValidationResult`` (via ``with`` or
            explicit ``__exit__``) to free native memory.

        Args:
            validation_input (MiseValidationInput): The input headers.
            context_callback: Synchronous callback that receives the request context.
            caller_context: Optional opaque context passed to the context callback.

        Returns:
            Future[MiseValidationResult]: A future that will contain the validation result.
        """
        future = Future()

        ctx_cb_handle = FFI_BROKER.callback("void(void*, void*)", context_callback)
        context_ptr = FFI_BROKER.NULL if caller_context is None else FFI_BROKER.new_handle(caller_context)

        @FFI_BROKER.callback("void(MiseValidationResult*, void*)")
        def _on_complete(result, ctx):
            try:
                wrapper = MiseValidationResult(FFI_BROKER.cast('MiseValidationResult*', result))
            except BaseException as e:
                # Construction failed before the wrapper took ownership; free the native
                # result here to avoid a leak.
                MISE_LIBRARY.MiseFreeValidationResult(result)
                _safe_set_exception(future, e)
                self._live_async_callbacks.discard(_on_complete)
                self._live_async_callbacks.discard(ctx_cb_handle)
                return
            try:
                future.set_result(wrapper)
            except BaseException as e:
                # Future already completed/cancelled. The wrapper now owns the native
                # pointer and frees it on GC — do not free it again here.
                _safe_set_exception(future, e)
            finally:
                self._live_async_callbacks.discard(_on_complete)
                self._live_async_callbacks.discard(ctx_cb_handle)

        # prevent GC of callbacks — safe for concurrent calls
        self._live_async_callbacks.add(ctx_cb_handle)
        self._live_async_callbacks.add(_on_complete)

        MISE_LIBRARY.MiseValidateWithContextAsync(
            validation_input.data,
            ctx_cb_handle,
            context_ptr,
            _on_complete,
            FFI_BROKER.NULL,  # nativeContext — closure captures state via Future.
        )

        return future

    def validate_with_azure_authorization_module_async(
        self,
        validation_input: MiseValidationInput,
        context_callback,
        caller_context=None,
    ) -> Future:
        """
        Asynchronously validates authentication with Azure Authorization module.

        .. important::
            The caller **must** close the returned ``MiseValidationResult`` (via ``with`` or
            explicit ``__exit__``) to free native memory.

        Args:
            validation_input (MiseValidationInput): The input headers.
            context_callback: Synchronous callback to set authorization payloads.
            caller_context: Optional opaque context passed to the context callback.

        Returns:
            Future[MiseValidationResult]: A future that will contain the validation result.
        """
        future = Future()

        ctx_cb_handle = FFI_BROKER.callback("void(void*, void*)", context_callback)
        context_ptr = FFI_BROKER.NULL if caller_context is None else FFI_BROKER.new_handle(caller_context)

        @FFI_BROKER.callback("void(MiseValidationResult*, void*)")
        def _on_complete(result, ctx):
            try:
                wrapper = MiseValidationResult(FFI_BROKER.cast('MiseValidationResult*', result))
            except BaseException as e:
                # Construction failed before the wrapper took ownership; free the native
                # result here to avoid a leak.
                MISE_LIBRARY.MiseFreeValidationResult(result)
                _safe_set_exception(future, e)
                self._live_async_callbacks.discard(_on_complete)
                self._live_async_callbacks.discard(ctx_cb_handle)
                return
            try:
                future.set_result(wrapper)
            except BaseException as e:
                # Future already completed/cancelled. The wrapper now owns the native
                # pointer and frees it on GC — do not free it again here.
                _safe_set_exception(future, e)
            finally:
                self._live_async_callbacks.discard(_on_complete)
                self._live_async_callbacks.discard(ctx_cb_handle)

        # prevent GC of callbacks — safe for concurrent calls
        self._live_async_callbacks.add(ctx_cb_handle)
        self._live_async_callbacks.add(_on_complete)

        MISE_LIBRARY.MiseValidateWithAzureAuthorizationModuleAsync(
            validation_input.data,
            ctx_cb_handle,
            context_ptr,
            _on_complete,
            FFI_BROKER.NULL,  # nativeContext — closure captures state via Future.
        )

        return future

    def get_authorization_header_async(
        self,
        validation_result: MiseValidationResult,
        header_input: MiseDownstreamAuthorizationHeaderInput,
        downstream_api_name: str,
    ) -> Future:
        """
        Asynchronously acquires an authorization header for calling a downstream API.

        .. important::
            The caller **must** close the returned ``MiseDownstreamAuthorizationHeaderResult``
            (via ``with`` or explicit ``__exit__``) to free native memory.

        Args:
            validation_result (MiseValidationResult): The result of the token validation.
            header_input (MiseDownstreamAuthorizationHeaderInput): Input parameters.
            downstream_api_name (str): The downstream API name from config.

        Returns:
            Future[MiseDownstreamAuthorizationHeaderResult]: A future with the result.
        """
        future = Future()

        @FFI_BROKER.callback("void(MiseDownstreamAuthorizationHeaderResult*, void*)")
        def _on_complete(result, ctx):
            try:
                wrapper = MiseDownstreamAuthorizationHeaderResult(
                    FFI_BROKER.cast('MiseDownstreamAuthorizationHeaderResult*', result))
            except BaseException as e:
                # Construction failed before the wrapper took ownership; free the native
                # result here to avoid a leak.
                MISE_LIBRARY.MiseFreeDownstreamAuthorizationHeaderResult(result)
                _safe_set_exception(future, e)
                self._live_async_callbacks.discard(_on_complete)
                return
            try:
                future.set_result(wrapper)
            except BaseException as e:
                # Future already completed/cancelled. The wrapper now owns the native
                # pointer and frees it on GC — do not free it again here.
                _safe_set_exception(future, e)
            finally:
                self._live_async_callbacks.discard(_on_complete)

        self._live_async_callbacks.add(_on_complete)

        MISE_LIBRARY.MiseGetAuthorizationHeaderAsync(
            validation_result.data,
            header_input.data,
            downstream_api_name.encode('utf-8'),
            _on_complete,
            FFI_BROKER.NULL,  # nativeContext — closure captures state via Future.
        )

        return future

    def get_authorization_header_unauthenticated_async(
        self,
        header_input: MiseDownstreamAuthorizationHeaderInput,
        downstream_api_name: str,
    ) -> Future:
        """
        Asynchronously acquires an authorization header without authentication.

        .. important::
            The caller **must** close the returned ``MiseDownstreamAuthorizationHeaderResult``
            (via ``with`` or explicit ``__exit__``) to free native memory.

        Args:
            header_input (MiseDownstreamAuthorizationHeaderInput): Input parameters.
            downstream_api_name (str): The downstream API name from config.

        Returns:
            Future[MiseDownstreamAuthorizationHeaderResult]: A future with the result.
        """
        future = Future()

        @FFI_BROKER.callback("void(MiseDownstreamAuthorizationHeaderResult*, void*)")
        def _on_complete(result, ctx):
            try:
                wrapper = MiseDownstreamAuthorizationHeaderResult(
                    FFI_BROKER.cast('MiseDownstreamAuthorizationHeaderResult*', result))
            except BaseException as e:
                # Construction failed before the wrapper took ownership; free the native
                # result here to avoid a leak.
                MISE_LIBRARY.MiseFreeDownstreamAuthorizationHeaderResult(result)
                _safe_set_exception(future, e)
                self._live_async_callbacks.discard(_on_complete)
                return
            try:
                future.set_result(wrapper)
            except BaseException as e:
                # Future already completed/cancelled. The wrapper now owns the native
                # pointer and frees it on GC — do not free it again here.
                _safe_set_exception(future, e)
            finally:
                self._live_async_callbacks.discard(_on_complete)

        self._live_async_callbacks.add(_on_complete)

        MISE_LIBRARY.MiseGetAuthorizationHeaderUnauthenticatedAsync(
            header_input.data,
            downstream_api_name.encode('utf-8'),
            _on_complete,
            FFI_BROKER.NULL,  # nativeContext — closure captures state via Future.
        )

        return future

    def call_downstream_api_async(
        self,
        validation_result: MiseValidationResult,
        api_input: MiseDownstreamApiInput,
        downstream_api_name: str,
    ) -> Future:
        """
        Asynchronously calls a downstream API with authentication.

        .. important::
            The caller **must** close the returned ``MiseDownstreamApiResult``
            (via ``with`` or explicit ``__exit__``) to free native memory.

        Args:
            validation_result (MiseValidationResult): The result of the token validation.
            api_input (MiseDownstreamApiInput): Input parameters for the API call.
            downstream_api_name (str): The downstream API name from config.

        Returns:
            Future[MiseDownstreamApiResult]: A future with the result.
        """
        future = Future()

        @FFI_BROKER.callback("void(MiseDownstreamApiResult*, void*)")
        def _on_complete(result, ctx):
            try:
                wrapper = MiseDownstreamApiResult(
                    FFI_BROKER.cast('MiseDownstreamApiResult*', result))
            except BaseException as e:
                # Construction failed before the wrapper took ownership; free the native
                # result here to avoid a leak.
                MISE_LIBRARY.MiseFreeDownstreamApiResult(result)
                _safe_set_exception(future, e)
                self._live_async_callbacks.discard(_on_complete)
                return
            try:
                future.set_result(wrapper)
            except BaseException as e:
                # Future already completed/cancelled. The wrapper now owns the native
                # pointer and frees it on GC — do not free it again here.
                _safe_set_exception(future, e)
            finally:
                self._live_async_callbacks.discard(_on_complete)

        self._live_async_callbacks.add(_on_complete)

        MISE_LIBRARY.MiseCallDownstreamApiAsync(
            validation_result.data,
            api_input.data,
            downstream_api_name.encode('utf-8'),
            _on_complete,
            FFI_BROKER.NULL,  # nativeContext — closure captures state via Future.
        )

        return future

    def call_downstream_api_unauthenticated_async(
        self,
        api_input: MiseDownstreamApiInput,
        downstream_api_name: str,
    ) -> Future:
        """
        Asynchronously calls a downstream API without authentication.

        .. important::
            The caller **must** close the returned ``MiseDownstreamApiResult``
            (via ``with`` or explicit ``__exit__``) to free native memory.

        Args:
            api_input (MiseDownstreamApiInput): Input parameters for the API call.
            downstream_api_name (str): The downstream API name from config.

        Returns:
            Future[MiseDownstreamApiResult]: A future with the result.
        """
        future = Future()

        @FFI_BROKER.callback("void(MiseDownstreamApiResult*, void*)")
        def _on_complete(result, ctx):
            try:
                wrapper = MiseDownstreamApiResult(
                    FFI_BROKER.cast('MiseDownstreamApiResult*', result))
            except BaseException as e:
                # Construction failed before the wrapper took ownership; free the native
                # result here to avoid a leak.
                MISE_LIBRARY.MiseFreeDownstreamApiResult(result)
                _safe_set_exception(future, e)
                self._live_async_callbacks.discard(_on_complete)
                return
            try:
                future.set_result(wrapper)
            except BaseException as e:
                # Future already completed/cancelled. The wrapper now owns the native
                # pointer and frees it on GC — do not free it again here.
                _safe_set_exception(future, e)
            finally:
                self._live_async_callbacks.discard(_on_complete)

        self._live_async_callbacks.add(_on_complete)

        MISE_LIBRARY.MiseCallDownstreamApiUnauthenticatedAsync(
            api_input.data,
            downstream_api_name.encode('utf-8'),
            _on_complete,
            FFI_BROKER.NULL,  # nativeContext — closure captures state via Future.
        )

        return future

    def assign_l2_cache_get_data_callback(
        self,
        callback,
        free_result_callback,
        native_context=None,
    ) -> MiseControlResult:
        """
        Assigns a user callback for the L2 cache get data function.

        This function needs to be called before 'MiseConfigure' and is expected to be called only once.

        Args:
            callback: The user-defined callback function to get data from L2 cache.
            free_result_callback: The user-defined callback function to free result memory.
            native_context: Optional: A user-defined pointer to additional native context.

        Returns:
            MiseControlResult: Result structure with ErrorCode set to 0 on success.

        Example:
            >>> def get_data_callback(context, native_context):
            >>>     result = mise.MiseL2CacheGetDataCallbackResult()
            >>>     result.cache_data = "cached_data"
            >>>     result.error_code = 0
            >>>     return result.data
            >>> def free_result(result):
            >>>     pass
            >>> result = mise_client.assign_l2_cache_get_data_callback(get_data_callback, free_result)
        """
        callback_handle = FFI_BROKER.callback(
            "const MiseL2CacheGetDataCallbackResult*(NativeL2CacheGetDataCallbackContext*, void*)",
            callback
        )
        free_callback_handle = FFI_BROKER.callback(
            "void(MiseL2CacheGetDataCallbackResult*)",
            free_result_callback
        )
        self._l2_cache_get_data_callback = callback_handle
        self._l2_cache_free_get_data_result_callback = free_callback_handle
        context_ptr = FFI_BROKER.NULL if native_context is None else FFI_BROKER.new_handle(native_context)

        res = MISE_LIBRARY.MiseAssignL2CacheGetDataCallback(
            callback_handle,
            free_callback_handle,
            context_ptr
        )

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def unassign_l2_cache_get_data_callback(self) -> MiseControlResult:
        """
        Unassigns the L2 cache get data callback function.

        Returns:
            MiseControlResult: Result structure with ErrorCode set to 0 on success.

        Example:
            >>> result = mise_client.unassign_l2_cache_get_data_callback()
        """
        self._l2_cache_get_data_callback = None
        self._l2_cache_free_get_data_result_callback = None
        res = MISE_LIBRARY.MiseUnassignL2CacheGetDataCallback()

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def assign_l2_cache_get_data_async_callback(
        self,
        callback,
        free_result_callback,
        native_context=None,
    ) -> MiseControlResult:
        """
        Assigns a non-blocking user callback for the L2 cache get data function.

        This function needs to be called before 'MiseConfigure' and is expected to be called only once.
        When both sync and async callbacks are assigned, the async callback takes precedence.

        Args:
            callback: The user-defined async callback function to get data from L2 cache. It receives
                the managed context, native context, completion callback, and completion context, then
                must invoke completion_callback(result, completion_context) exactly once when done.
            free_result_callback: The user-defined callback function to free result memory.
            native_context: Optional: A user-defined pointer to additional native context.

        Returns:
            MiseControlResult: Result structure with ErrorCode set to 0 on success.

        Example:
            >>> def get_data_async_callback(context, native_context, completion_callback, completion_context):
            >>>     result = mise.MiseL2CacheGetDataCallbackResult()
            >>>     result.cache_data = "cached_data"
            >>>     result.error_code = 0
            >>>     completion_callback(result, completion_context)
            >>> def free_result(result):
            >>>     pass
            >>> result = mise_client.assign_l2_cache_get_data_async_callback(get_data_async_callback, free_result)
        """
        callback_handle = FFI_BROKER.callback(
            "void(NativeL2CacheGetDataCallbackContext*, void*, "
            "MiseL2CacheGetDataCompletionCallbackFunc, void*)",
            callback
        )
        free_callback_handle = FFI_BROKER.callback(
            "void(MiseL2CacheGetDataCallbackResult*)",
            free_result_callback
        )
        self._l2_cache_get_data_async_callback = callback_handle
        self._l2_cache_free_get_data_async_result_callback = free_callback_handle
        context_ptr = FFI_BROKER.NULL if native_context is None else FFI_BROKER.new_handle(native_context)

        res = MISE_LIBRARY.MiseAssignL2CacheGetDataAsyncCallback(
            callback_handle,
            free_callback_handle,
            context_ptr
        )

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def unassign_l2_cache_get_data_async_callback(self) -> MiseControlResult:
        """
        Unassigns the non-blocking L2 cache get data callback function.

        Returns:
            MiseControlResult: Result structure with ErrorCode set to 0 on success.

        Example:
            >>> result = mise_client.unassign_l2_cache_get_data_async_callback()
        """
        self._l2_cache_get_data_async_callback = None
        self._l2_cache_free_get_data_async_result_callback = None
        res = MISE_LIBRARY.MiseUnassignL2CacheGetDataAsyncCallback()

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def assign_l2_cache_set_data_callback(
        self,
        callback,
        free_result_callback,
        native_context=None,
    ) -> MiseControlResult:
        """
        Assigns a user callback for the L2 cache set data function.

        This function needs to be called before 'MiseConfigure' and is expected to be called only once.

        Args:
            callback: The user-defined callback function to set data in L2 cache.
            free_result_callback: The user-defined callback function to free result memory.
            native_context: Optional: A user-defined pointer to additional native context.

        Returns:
            MiseControlResult: Result structure with ErrorCode set to 0 on success.

        Example:
            >>> def set_data_callback(context, native_context):
            >>>     result = mise.MiseL2CacheSetDataCallbackResult()
            >>>     result.error_code = 0
            >>>     return result.data
            >>> def free_result(result):
            >>>     pass
            >>> result = mise_client.assign_l2_cache_set_data_callback(set_data_callback, free_result)
        """
        callback_handle = FFI_BROKER.callback(
            "const MiseL2CacheSetDataCallbackResult*(NativeL2CacheSetDataCallbackContext*, void*)",
            callback
        )
        free_callback_handle = FFI_BROKER.callback(
            "void(MiseL2CacheSetDataCallbackResult*)",
            free_result_callback
        )
        self._l2_cache_set_data_callback = callback_handle
        self._l2_cache_free_set_data_result_callback = free_callback_handle
        context_ptr = FFI_BROKER.NULL if native_context is None else FFI_BROKER.new_handle(native_context)

        res = MISE_LIBRARY.MiseAssignL2CacheSetDataCallback(
            callback_handle,
            free_callback_handle,
            context_ptr
        )

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def unassign_l2_cache_set_data_callback(self) -> MiseControlResult:
        """
        Unassigns the L2 cache set data callback function.

        Returns:
            MiseControlResult: Result structure with ErrorCode set to 0 on success.

        Example:
            >>> result = mise_client.unassign_l2_cache_set_data_callback()
        """
        self._l2_cache_set_data_callback = None
        self._l2_cache_free_set_data_result_callback = None
        res = MISE_LIBRARY.MiseUnassignL2CacheSetDataCallback()

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def assign_l2_cache_set_data_async_callback(
        self,
        callback,
        free_result_callback,
        native_context=None,
    ) -> MiseControlResult:
        """
        Assigns a non-blocking user callback for the L2 cache set data function.

        This function needs to be called before 'MiseConfigure' and is expected to be called only once.
        When both sync and async callbacks are assigned, the async callback takes precedence.

        Args:
            callback: The user-defined async callback function to set data in L2 cache. It receives
                the managed context, native context, completion callback, and completion context, then
                must invoke completion_callback(result, completion_context) exactly once when done.
            free_result_callback: The user-defined callback function to free result memory.
            native_context: Optional: A user-defined pointer to additional native context.

        Returns:
            MiseControlResult: Result structure with ErrorCode set to 0 on success.

        Example:
            >>> def set_data_async_callback(context, native_context, completion_callback, completion_context):
            >>>     result = mise.MiseL2CacheSetDataCallbackResult()
            >>>     result.error_code = 0
            >>>     completion_callback(result, completion_context)
            >>> def free_result(result):
            >>>     pass
            >>> result = mise_client.assign_l2_cache_set_data_async_callback(set_data_async_callback, free_result)
        """
        callback_handle = FFI_BROKER.callback(
            "void(NativeL2CacheSetDataCallbackContext*, void*, "
            "MiseL2CacheSetDataCompletionCallbackFunc, void*)",
            callback
        )
        free_callback_handle = FFI_BROKER.callback(
            "void(MiseL2CacheSetDataCallbackResult*)",
            free_result_callback
        )
        self._l2_cache_set_data_async_callback = callback_handle
        self._l2_cache_free_set_data_async_result_callback = free_callback_handle
        context_ptr = FFI_BROKER.NULL if native_context is None else FFI_BROKER.new_handle(native_context)

        res = MISE_LIBRARY.MiseAssignL2CacheSetDataAsyncCallback(
            callback_handle,
            free_callback_handle,
            context_ptr
        )

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def unassign_l2_cache_set_data_async_callback(self) -> MiseControlResult:
        """
        Unassigns the non-blocking L2 cache set data callback function.

        Returns:
            MiseControlResult: Result structure with ErrorCode set to 0 on success.

        Example:
            >>> result = mise_client.unassign_l2_cache_set_data_async_callback()
        """
        self._l2_cache_set_data_async_callback = None
        self._l2_cache_free_set_data_async_result_callback = None
        res = MISE_LIBRARY.MiseUnassignL2CacheSetDataAsyncCallback()

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def assign_rbac_change_event_notification_filter_callback(
        self,
        callback,
        native_context=None,
    ) -> MiseControlResult:
        """
        Assigns a user callback for filtering RBAC change event notifications.

        This function needs to be called before 'MiseConfigure' and is expected to be called only once.

        Args:
            callback: The user-defined callback function for filtering.
            native_context: Optional: A user-defined pointer to additional native context.

        Returns:
            MiseControlResult: Result structure with ErrorCode set to 0 on success.

        Example:
            >>> def rbac_filter(tenant_id, resource_ids, resource_ids_count, context):
            >>>     return True
            >>> result = mise_client.assign_rbac_change_event_notification_filter_callback(rbac_filter)
        """
        callback_handle = FFI_BROKER.callback("bool(const char*, const char**, unsigned int, void*)", callback)
        self._rbac_filter_callback = callback_handle
        context_ptr = FFI_BROKER.NULL if native_context is None else FFI_BROKER.new_handle(native_context)

        res = MISE_LIBRARY.MiseAssignRbacChangeEventNotificationFilterCallback(
            callback_handle,
            context_ptr
        )

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def unassign_rbac_change_event_notification_filter_callback(self) -> MiseControlResult:
        """
        Unassigns the RBAC change event notification filter callback function.

        Returns:
            MiseControlResult: Result structure with ErrorCode set to 0 on success.

        Example:
            >>> result = mise_client.unassign_rbac_change_event_notification_filter_callback()
        """
        self._rbac_filter_callback = None
        res = MISE_LIBRARY.MiseUnassignRbacChangeEventNotificationFilterCallback()

        return MiseControlResult(FFI_BROKER.cast('MiseControlResult*', res))

    def mise_free_log_message_callback_context(
        self,
        result: MiseLogMessageCallbackContext,
    ) -> None:
        """Frees resources allocated for a MiseLogMessageCallbackContext."""
        MISE_LIBRARY.MiseFreeLogMessageCallbackContext(result.data)

    def free_l2_cache_get_data_callback_context(
        self,
        context: NativeL2CacheGetDataCallbackContext,
    ) -> None:
        """
        Deprecated: The managed runtime now owns and frees the callback context automatically.
        This method is retained for API compatibility but is a no-op.

        Args:
            context (NativeL2CacheGetDataCallbackContext): The context (ignored).
        """
        pass

    def free_l2_cache_set_data_callback_context(
        self,
        context: NativeL2CacheSetDataCallbackContext,
    ) -> None:
        """
        Deprecated: The managed runtime now owns and frees the callback context automatically.
        This method is retained for API compatibility but is a no-op.

        Args:
            context (NativeL2CacheSetDataCallbackContext): The context (ignored).
        """
        pass

    def get_system_info(self):
        # Get system name and machine type, converted to lowercase for uniformity
        system_name = platform.system().lower()
        machine_type = platform.machine().lower()

        # Define mapping for architectures
        architecture_map = {
            "x86_64": "x64",
            "amd64": "x64",
            "arm64": "arm64"
        }

        # Map system names to lowercase directly
        os_name = system_name  # Already lowercase
        architecture = architecture_map.get(machine_type, "unknown")

        return os_name, architecture